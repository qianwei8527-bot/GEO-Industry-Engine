# V10.6-R3-FIX2 最终收口交付 MANIFEST

- 任务编号：V10.6-R3-FIX2-FINAL-CLOSEOUT
- 前置状态：V10.6-R3-FIX1 已实施
- 是否允许部署：否
- 是否允许提交或推送：否
- 交付包：V10.6-R3-FIX2-最终收口-执行文件.zip

## 文件清单（ZIP 路径 / 仓库源路径 / SHA-256）

`MANIFEST.md` 为本清单文件，不计算自身哈希；ZIP 内路径全部为 ASCII。

| ZIP路径（ASCII） | 仓库源路径 | SHA-256 |
| --- | --- | --- |
| docs/18-0_V10.6-R3-FIX2-final-closeout-report.md | docs/18-0_V10.6-R3-FIX2-final-closeout-report.md | FCF6B7E03032140315CF0D7EA1679CE8C33D080D7165AA325A34A3C017C68669 |
| docs/V10.6-R3-code-change-list.md | docs/V10.6-R3-code-change-list.md | 709952DA5E8BA75B1C5D1CB4BB0D5C72C51EDFFBF4CD4D48485B7807E98C5640 |
| docs/17-9_V10.6-R3-FIX1-acceptance-correction-report.md | docs/17-9_V10.6-R3-FIX1-acceptance-correction-report.md | 9D22B90427249E64695EEA4C0845DE922A82CD6C3F40E80E7F5922ADFAA7C9FA |
| docs/17-8_V10.6-R3-project-plan-execution-report.md | docs/17-8_V10.6-R3-project-plan-execution-report.md | 6BC151AE93971A1DE595AD92BAEE29D1A5BD8B7C2103828BCD972C7B34B6198B |
| docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | ECFB32AE6FDC63C703DE2B123F5189F29DAB9CAB48230B3F83E9048147BE34A8 |
| docs/17-6_V10.6-R2.1-FIX1-acceptance-correction-report.md | docs/17-6_V10.6-R2.1-FIX1验收修正执行报告.md | 9195D3DEE54F605340138890962A93A3EE32553B718D50E18250B070F97D3558 |
| docs/17-5_V10.6-R2.1-UI-delivery-closeout-report.md | docs/17-5_V10.6-R2.1UI同步与交付收口执行报告.md | 5F17C384B0EA7FD9A7DE373326D35E7E0A20139F059294EFBE8D1092C0EB1D0C |
| docs/17-4_V10.6-R2-client-positioning-report.md | docs/17-4_V10.6-R2客户与定位执行报告.md | 03D6D1AF5E2C25DD3AB7E863A9C405D5606907004E46EA67AE6A2C59A2741461 |
| docs/v106-all-pages-design-preview.html | docs/v106-all-pages-design-preview.html | 5E20C1160711CED6B708891A02C9BAF23ED271992206EB4C4679093C807BD194 |
| docs/V10.6-UI-SYNC-PROTOCOL.md | docs/V10.6-UI-SYNC-PROTOCOL.md | F4CF4D1471902F131DEED0F6D9F6AC86E6BC0C5B7B810D8D04DF59373A7EFA84 |
| docs/V10.6-R2.1-code-change-list.md | docs/V10.6-R2.1-代码变更清单.md | EE1D81B1821805DD86B40C0EA9F1E124776899283EC919CE54E00F8D8C087635 |
| docs/18-3-page-integration-list.md | docs/18-3_页面整合清单.md | FB29908D3C7CB9385881F6E0F6D1248D85B4B83EB66DD3495F35FF77F20AF93E |
| config/universe/project_plan.yaml | config/universe/project_plan.yaml | 79DD02EFB3559010E83988D37C4DF3B54B8309CF8425C2ABDC30D30F5E33C745 |
| config/universe/geo_project.yaml | config/universe/geo_project.yaml | D69A31F702B3AEC8D886799A6F765580CFCE83AB40FB719178C5880BAB25D6E6 |
| config/universe/positioning.yaml | config/universe/positioning.yaml | DA38E7B02B1AF762A4375E936922E2D44180F2C6C91A81FD05A9F9ED4D4195A2 |
| config/universe/realm_governance.yaml | config/universe/realm_governance.yaml | 22198BD767C31818B66B41EFF6A3DD8E51EA49D11FE3C5AC919A969FD5EF6D4F |
| backend/app/services/project_plan_service.py | backend/app/services/project_plan_service.py | 6665F0B8AA473B0900022A71AD4D91170A96B617194DE9B3A395C469600AA409 |
| backend/app/api/v1/project_plans.py | backend/app/api/v1/project_plans.py | 82C139AB56867EDB51A9573CE65C0CC9CA211CB252E29809FCA9CC0299E21A58 |
| backend/app/main.py | backend/app/main.py | 06FF45C55B9ED2CA871FF0430A962A253084269DB484A596F9D6E4AD5E1A948E |
| backend/tests/test_v10p6_r3_project_plan.py | backend/tests/test_v10p6_r3_project_plan.py | 88C30EC24087C4AB5C8469FD83C1BA538A37190CA0E9F24F1B14E467EEB01CD8 |
| backend/tests/test_v10p6_r2_client_positioning.py | backend/tests/test_v10p6_r2_client_positioning.py | 812C9A1D9EA40BC918387B0CC98F16035D33A8A67201AE9BD9AF51495558A2A1 |
| backend/tests/test_v10p6_r1_public_intake.py | backend/tests/test_v10p6_r1_public_intake.py | 4F425351932CFDBAE208C5B58BB44A197F3B96FCB5F33EF183F36EC1621F293C |
| frontend/src/components/realm-owner/project-plan-workbench.tsx | frontend/src/components/realm-owner/project-plan-workbench.tsx | CB3B08DA1CA62AE1E9A46B2546C682D8879F54DCD13C6CCB7E2D573895A62E04 |
| frontend/src/lib/realm-owner/r3-project-plan.ts | frontend/src/lib/realm-owner/r3-project-plan.ts | 1C581A2B391971452579906F937407B8AD4DE5BE8952004A162198A6D0C1324D |
| frontend/src/components/realm-owner/realm-owner-section-page.tsx | frontend/src/components/realm-owner/realm-owner-section-page.tsx | BA788C0AC54BF1B0A5A3DDE744FD30807BE741F7C71548C4E632C9AFEE2C4D43 |
| frontend/src/components/app-shell/surface-config.ts | frontend/src/components/app-shell/surface-config.ts | 54B97805508398ABFA5877C19F26F4B2DEEB8985391AA4C757A3D32570837C72 |
| frontend/src/app/realm/[realm_id]/projects/page.tsx | frontend/src/app/realm/[realm_id]/projects/page.tsx | 3EB9641E4481F8F3ABAF488855EDA317D93E04655E4F2A9130BD1AFE2E300743 |
| frontend/next.config.js | frontend/next.config.js | E3D0EC5F335EFD17BE545A47C4DE8F2DC4EDF8E3F65D1D26068FDF97501EC250 |
| frontend/package.json | frontend/package.json | 9F4F6727EC33B2E49837CD167EDA8530FF2E2703F09AEFEED8759B989BC0845B |
| frontend/tests/realm-owner-home/r3-project-plan.test.ts | frontend/tests/realm-owner-home/r3-project-plan.test.ts | 40FE04DD4439AE6F28CC75BF38E24A328F3BD22564F7EBD549DEC73A5B03279F |
| frontend/tests/realm-owner-home/adapter.test.ts | frontend/tests/realm-owner-home/adapter.test.ts | 4E3B9DEBFF5469FC033551E6078BD1FEFC964E7F8DD7C41C4205749C422E8677 |
| frontend/tests/realm-owner-home/ts-loader.mjs | frontend/tests/realm-owner-home/ts-loader.mjs | 25425BCB900182079E6C503BD17368826698A1A8A7C7DF89927DA131D97A2110 |
| frontend/tests/public-intake/form.test.ts | frontend/tests/public-intake/form.test.ts | EEF1B608239BF1A9DACDAFAE6A34B9BAB1246F8972ED42F3590C7D5C608E21EC |
| frontend/tests/operations/operations-adapter.test.ts | frontend/tests/operations/operations-adapter.test.ts | 8B3728B43801F19CB5A3F4A2592FD86B865DDCF0FA87D320F5F042F2297DDC0F |
| frontend/scripts/check-v106-preview.mjs | frontend/scripts/check-v106-preview.mjs | FA3B8440DBB42741329EBC94A6D48BF73A17A9C5273BB1BAE502CB932B395F45 |
| frontend/scripts/capture-v106-r3-screenshots.mjs | frontend/scripts/capture-v106-r3-screenshots.mjs | 3B30DAD7900A3A5024C1F481D5518F337AB032F323FDC7871D25521B419CDF94 |
| frontend/scripts/capture-v106-r3-real-screenshots.mjs | frontend/scripts/capture-v106-r3-real-screenshots.mjs | 4D0B4AA092D94CAE506D410F09CE78B2821735465EBEB6DA03B1D01C35E69DD7 |
| frontend/scripts/capture-v106-r21-preview-states.mjs | frontend/scripts/capture-v106-r21-preview-states.mjs | 26C8067DCF10FF8F9B05F61F12B6753783B765A1DFBF22972BFB4D2A977C2D40 |
| scripts/verify_v106_r3_fix2_package.py | scripts/verify_v106_r3_fix2_package.py | AEFA38C56DE6F27438C4AFF0158026F313B8A592FEDC9BB52947EE10D9101E62 |
| scripts/verify_v106_r3_fix1_package.py | scripts/verify_v106_r3_fix1_package.py | BC6621D99C6E6A47F0B45CED23D0AE90F1D8AE43E4B6C8E48726DB4127DAEA7A |
| docs/generated_images/V10.6-R3-01-projects-empty.png | docs/generated_images/V10.6-R3-01-projects-empty.png | ECE0C5B2FA1193078C931C7D5753DFB9D8D9B4C3B4BDB05989AB4AD8A1FBF3B9 |
| docs/generated_images/V10.6-R3-02-r2-project-enter.png | docs/generated_images/V10.6-R3-02-r2-project-enter.png | FEEF49311A4878255A0ACCDC9535F6901D5C77B889F19C7D1496A05C748F00D5 |
| docs/generated_images/V10.6-R3-14-no-permission.png | docs/generated_images/V10.6-R3-14-no-permission.png | B2F04583A5DF6DE483C37A017F0150B70A28F51C7265F0DB00A8C30B04B76F2C |
| docs/generated_images/V10.6-R3-15-narrow-responsive.png | docs/generated_images/V10.6-R3-15-narrow-responsive.png | 4363165D21409541B11E755E4D46750E929D9759C212ED49233B26D89624FAD0 |
| docs/generated_images/V10.6-R3-REAL-01-projects-page.png | docs/generated_images/V10.6-R3-REAL-01-projects-page.png | 7F797E60DF280612EF4C99913B842E385D6F30DEF7F88ED20C589F9E4A681F61 |
| docs/generated_images/V10.6-R3-REAL-02-tasks-progress-overdue.png | docs/generated_images/V10.6-R3-REAL-02-tasks-progress-overdue.png | 56CD6AC0AB5A581D7DB483F9E46251189A34A27CC86885707AAE24E427458920 |
| docs/generated_images/V10.6-R3-REAL-03-narrow-responsive.png | docs/generated_images/V10.6-R3-REAL-03-narrow-responsive.png | 8D71965E54434327B8B99D614B179F4C7DEE68A4BB4B1BD1A77879DD39D64EB7 |
| docs/generated_images/V10.6-R3-REAL-04-no-permission.png | docs/generated_images/V10.6-R3-REAL-04-no-permission.png | F7145EEDBC3352B989F9044BF9AB170D1A7047EBA4B2186D8D8DC42E400791D0 |
| docs/generated_images/V10.6-R3-mock-state-blocked.png | docs/generated_images/V10.6-R3-mock-state-blocked.png | 0EA096E9AEDCC84E3E13C19AF7675D71D0B70ADBD86D5D046E8C84AED367CF93 |
| docs/generated_images/V10.6-R3-mock-state-empty.png | docs/generated_images/V10.6-R3-mock-state-empty.png | ECE0C5B2FA1193078C931C7D5753DFB9D8D9B4C3B4BDB05989AB4AD8A1FBF3B9 |
| docs/generated_images/V10.6-R3-mock-state-error.png | docs/generated_images/V10.6-R3-mock-state-error.png | BDF69EB235E0C645613F442D3D7388AD1FE7E9E4EDD2A174B520380A1450A410 |
| docs/generated_images/V10.6-R3-mock-state-loading.png | docs/generated_images/V10.6-R3-mock-state-loading.png | 33C7A46200F6A2899B04A144D6030A98C939B62F01152AE128892E1962F87B3C |
| docs/generated_images/V10.6-R3-mock-state-no-permission.png | docs/generated_images/V10.6-R3-mock-state-no-permission.png | B2F04583A5DF6DE483C37A017F0150B70A28F51C7265F0DB00A8C30B04B76F2C |
| docs/generated_images/V10.6-R3-mock-state-normal.png | docs/generated_images/V10.6-R3-mock-state-normal.png | FEEF49311A4878255A0ACCDC9535F6901D5C77B889F19C7D1496A05C748F00D5 |
| docs/generated_images/V10.6-R3-mock-state-partial.png | docs/generated_images/V10.6-R3-mock-state-partial.png | F5700E83FA844FCD01489ABB317FE856A861CE3A1951DAB5B466C1218DA6928A |

## 测试结果摘要

- 后端全量：332 passed。
- R3-FIX2 专项：32 passed。
- 前端测试：23 passed。
- TypeScript：通过。
- lint：通过，仅仓库原有 4 项 warning。
- production build：通过，54 个路由。
- 预览检查：PASS pages=36 meta=36 customerStates=7 projectStates=7。
- 交付包自检：PASS。

## 未完成项

- 真实 Realm 模板归属需后续数据模型支撑，当前未开放 realm_template。
- R4 变更控制、问题库、Skill 沉淀未开发。

## 已知风险

- owner_defined 模板通过 JSON 提交，模板管理页留待后续。
- 提醒只做本地记录，不发送外部消息。

## 敏感信息检查结果

- 未包含 `.env`。
- 未包含 Token、API Key、客户隐私或数据库转储。
- 截图来自脱机 Mock 与隔离 fixture 环境。
