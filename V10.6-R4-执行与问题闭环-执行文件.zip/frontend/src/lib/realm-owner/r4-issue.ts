import { authedFetch } from "../authFetch";

async function parseJson<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let message = `请求失败 (${res.status})`;
    try {
      const data = (await res.json()) as { detail?: string; message?: string };
      message = data.detail || data.message || message;
    } catch {
      // keep fallback
    }
    throw { status: res.status, message } as { status: number; message: string };
  }
  return res.json() as Promise<T>;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  return parseJson<T>(await authedFetch(path, options));
}

export interface IssuePermissions {
  can_create_issue: boolean;
  can_triage: boolean;
  can_update_issue: boolean;
  can_add_attempt: boolean;
  can_resolve: boolean;
  can_verify: boolean;
  can_generate_skill: boolean;
  can_confirm_skill: boolean;
}

export interface IssueEventItem {
  id: string;
  event_version: number;
  event_type: string;
  actor_id: string | null;
  actor_label: string | null;
  content: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string | null;
}

export interface IssueItem {
  id: string;
  issue_code: string;
  realm_id: string;
  project_id: string | null;
  work_item_id: string | null;
  original_text: string;
  title: string | null;
  scenario: string | null;
  impact: string | null;
  urgency: string | null;
  source_type: string;
  truth_scope: string;
  category: string | null;
  severity: string;
  status: string;
  version: number;
  classification_status: string;
  ai_classification: Record<string, unknown> | null;
  events: IssueEventItem[];
  permissions: IssuePermissions;
  created_at: string | null;
  updated_at: string | null;
}

export interface SkillDraftItem {
  id: string;
  project_id: string;
  artifact_type: string;
  title: string;
  status: string;
  content_json: Record<string, unknown>;
  metadata_json: Record<string, unknown>;
  created_at: string | null;
}

export async function fetchIssues(realmId: string, projectId?: string): Promise<IssueItem[]> {
  const q = new URLSearchParams({ realm_id: realmId });
  if (projectId) q.set("project_id", projectId);
  const data = await request<{ issues: IssueItem[] }>(`/issues?${q.toString()}`);
  return data.issues;
}

export async function fetchIssue(issueId: string): Promise<IssueItem> {
  return request<IssueItem>(`/issues/${encodeURIComponent(issueId)}`);
}

export async function createIssue(input: Record<string, unknown>): Promise<IssueItem> {
  return request<IssueItem>("/issues", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
}

export async function updateIssue(
  issueId: string,
  data: Record<string, unknown>,
  expectedVersion: number,
): Promise<IssueItem> {
  return request<IssueItem>(`/issues/${encodeURIComponent(issueId)}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...data, expected_version: expectedVersion }),
  });
}

export async function classifyIssue(issueId: string): Promise<IssueItem> {
  return request<IssueItem>(`/issues/${encodeURIComponent(issueId)}/classify`, { method: "POST" });
}

export async function addIssueAttempt(issueId: string, method: string, expectedVersion: number): Promise<IssueItem> {
  return request<IssueItem>(`/issues/${encodeURIComponent(issueId)}/attempts`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ method, expected_version: expectedVersion }),
  });
}

export async function resolveIssue(issueId: string, expectedVersion: number): Promise<IssueItem> {
  return request<IssueItem>(`/issues/${encodeURIComponent(issueId)}/resolve`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ expected_version: expectedVersion }),
  });
}

export async function verifyIssue(issueId: string, expectedVersion: number): Promise<IssueItem> {
  return request<IssueItem>(`/issues/${encodeURIComponent(issueId)}/verify`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ expected_version: expectedVersion }),
  });
}

export async function generateIssueSkill(issueIds: string[]): Promise<SkillDraftItem> {
  return request<SkillDraftItem>(`/issues/${encodeURIComponent(issueIds[0])}/skills/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ issue_ids: issueIds }),
  });
}

export async function fetchSkillDrafts(projectId?: string): Promise<SkillDraftItem[]> {
  const q = projectId ? `?project_id=${encodeURIComponent(projectId)}` : "";
  const data = await request<{ skills: SkillDraftItem[] }>(`/issues/skills${q}`);
  return data.skills;
}

export async function confirmSkillDraft(artifactId: string, confirmed: boolean): Promise<SkillDraftItem> {
  return request<SkillDraftItem>(`/issues/skills/${encodeURIComponent(artifactId)}/confirm`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ confirmed }),
  });
}
