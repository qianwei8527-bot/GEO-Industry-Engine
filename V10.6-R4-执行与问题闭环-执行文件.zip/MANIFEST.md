# V10.6-R4 执行与问题闭环交付 MANIFEST

- 任务编号：V10.6-R4-ISSUE-CLOSED-LOOP
- 前置版本：V10.6-R3-FIX2.1-FINAL-FREEZE
- 是否允许部署：否
- 是否允许提交或推送：否
- 交付包：V10.6-R4-执行与问题闭环-执行文件.zip

## 文件清单（ZIP 路径 / 仓库源路径 / SHA-256）

`MANIFEST.md` 为本清单文件，不计算自身哈希；ZIP 内路径全部为 ASCII。

| ZIP路径（ASCII） | 仓库源路径 | SHA-256 |
| --- | --- | --- |
| docs/18-2_V10.6-R4-execution-issue-closed-loop-report.md | docs/18-2_V10.6-R4-execution-issue-closed-loop-report.md | ECEC70E2343938958BA3316B48C6ED54C018FCED900531993B0D524587F02950 |
| docs/V10.6-R4-code-change-list.md | docs/V10.6-R4-code-change-list.md | FAC4EDE941DDB34728C41BE491E0DC0B3B6B01D66DCEF5D17A3B66EBA9EC950A |
| docs/18-1_V10.6-R3-FIX2.1-final-freeze-report.md | docs/18-1_V10.6-R3-FIX2.1-final-freeze-report.md | 514E1A1F02AEDA72B193797E1D1EB5490CAC68E33EE13C83065E9F68964C9D94 |
| docs/V10.6-R3-code-change-list.md | docs/V10.6-R3-code-change-list.md | 304A678282529791A9C3856FCA84446451205E25338CE97051366757D3867B9C |
| docs/18-0_V10.6-R3-FIX2-final-closeout-report.md | docs/18-0_V10.6-R3-FIX2-final-closeout-report.md | FCF6B7E03032140315CF0D7EA1679CE8C33D080D7165AA325A34A3C017C68669 |
| docs/17-9_V10.6-R3-FIX1-acceptance-correction-report.md | docs/17-9_V10.6-R3-FIX1-acceptance-correction-report.md | 9D22B90427249E64695EEA4C0845DE922A82CD6C3F40E80E7F5922ADFAA7C9FA |
| docs/17-8_V10.6-R3-project-plan-execution-report.md | docs/17-8_V10.6-R3-project-plan-execution-report.md | 6BC151AE93971A1DE595AD92BAEE29D1A5BD8B7C2103828BCD972C7B34B6198B |
| docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | ECFB32AE6FDC63C703DE2B123F5189F29DAB9CAB48230B3F83E9048147BE34A8 |
| docs/17-6_V10.6-R2.1-FIX1-acceptance-correction-report.md | docs/17-6_V10.6-R2.1-FIX1验收修正执行报告.md | 9195D3DEE54F605340138890962A93A3EE32553B718D50E18250B070F97D3558 |
| docs/17-5_V10.6-R2.1-UI-delivery-closeout-report.md | docs/17-5_V10.6-R2.1UI同步与交付收口执行报告.md | 5F17C384B0EA7FD9A7DE373326D35E7E0A20139F059294EFBE8D1092C0EB1D0C |
| docs/17-4_V10.6-R2-client-positioning-report.md | docs/17-4_V10.6-R2客户与定位执行报告.md | 03D6D1AF5E2C25DD3AB7E863A9C405D5606907004E46EA67AE6A2C59A2741461 |
| docs/v106-all-pages-design-preview.html | docs/v106-all-pages-design-preview.html | D5C97BE03ECE5CD41D0292CCEAF7CE377C32D340F32B96156023FBCA21CCAA30 |
| docs/V10.6-UI-SYNC-PROTOCOL.md | docs/V10.6-UI-SYNC-PROTOCOL.md | F4CF4D1471902F131DEED0F6D9F6AC86E6BC0C5B7B810D8D04DF59373A7EFA84 |
| docs/V10.6-R2.1-code-change-list.md | docs/V10.6-R2.1-代码变更清单.md | EE1D81B1821805DD86B40C0EA9F1E124776899283EC919CE54E00F8D8C087635 |
| docs/18-3-page-integration-list.md | docs/18-3_页面整合清单.md | FB29908D3C7CB9385881F6E0F6D1248D85B4B83EB66DD3495F35FF77F20AF93E |
| config/universe/project_plan.yaml | config/universe/project_plan.yaml | 79DD02EFB3559010E83988D37C4DF3B54B8309CF8425C2ABDC30D30F5E33C745 |
| config/universe/geo_project.yaml | config/universe/geo_project.yaml | D69A31F702B3AEC8D886799A6F765580CFCE83AB40FB719178C5880BAB25D6E6 |
| config/universe/positioning.yaml | config/universe/positioning.yaml | DA38E7B02B1AF762A4375E936922E2D44180F2C6C91A81FD05A9F9ED4D4195A2 |
| config/universe/realm_governance.yaml | config/universe/realm_governance.yaml | 22198BD767C31818B66B41EFF6A3DD8E51EA49D11FE3C5AC919A969FD5EF6D4F |
| backend/alembic/versions/v10p8a1b2c3d4_v10p8_issue_closed_loop.py | backend/alembic/versions/v10p8a1b2c3d4_v10p8_issue_closed_loop.py | A12DC0C0D259DFDEF5667BF768A06415ED1399704E4399636BD8A0393197CB0D |
| backend/app/models/issue.py | backend/app/models/issue.py | F666E6BD39350C2B6A81AF09683AEF6A06064FED7240C2237BD76B52B3410AEE |
| backend/app/services/issue_service.py | backend/app/services/issue_service.py | D54546D0A9187098A52A38CD007180AC3C666104F865C2CDB3DD6994338A1F0B |
| backend/app/api/v1/issues.py | backend/app/api/v1/issues.py | 73481508099594FC2827E8DCE210E0C61F873C9519BFE399597ED01C4FCEF7D9 |
| backend/app/services/project_plan_service.py | backend/app/services/project_plan_service.py | C494C921A1294EE06AEBC2024009673485472F81549E58CD448D805C0096E497 |
| backend/app/api/v1/project_plans.py | backend/app/api/v1/project_plans.py | 82C139AB56867EDB51A9573CE65C0CC9CA211CB252E29809FCA9CC0299E21A58 |
| backend/app/main.py | backend/app/main.py | 06FF45C55B9ED2CA871FF0430A962A253084269DB484A596F9D6E4AD5E1A948E |
| backend/tests/test_v10p6_r4_issue_closed_loop.py | backend/tests/test_v10p6_r4_issue_closed_loop.py | 1C97A446F2928FD2F8E4279C5B30CBC74942D1FA7EFD4E6C846B08418C5C1F5B |
| backend/tests/test_v10p5_lightweight_execution.py | backend/tests/test_v10p5_lightweight_execution.py | E9D3269B477D95EC930C29676010066F24C050249B7575FDFEEB6C599886B66C |
| backend/tests/test_v10p6_r3_project_plan.py | backend/tests/test_v10p6_r3_project_plan.py | E0DF4A168869803D1ECFD25EDDE992F3BF13E24F9CE18B546823A43BEA0DE15F |
| backend/tests/test_v10p6_r2_client_positioning.py | backend/tests/test_v10p6_r2_client_positioning.py | 812C9A1D9EA40BC918387B0CC98F16035D33A8A67201AE9BD9AF51495558A2A1 |
| backend/tests/test_v10p6_r1_public_intake.py | backend/tests/test_v10p6_r1_public_intake.py | 4F425351932CFDBAE208C5B58BB44A197F3B96FCB5F33EF183F36EC1621F293C |
| frontend/src/lib/realm-owner/r4-issue.ts | frontend/src/lib/realm-owner/r4-issue.ts | 01258FF5E76CDD49D40010028A7A20B3D91FD80C48D86F93194472DF173F2FBE |
| frontend/src/components/realm-owner/issue-closed-loop-workbench.tsx | frontend/src/components/realm-owner/issue-closed-loop-workbench.tsx | D9B10B989F0F66AA467257B97D3D093674BDC617CB7B215B5DF23DB8208CCEDA |
| frontend/src/components/realm-owner/project-plan-workbench.tsx | frontend/src/components/realm-owner/project-plan-workbench.tsx | 35E58139D42A1E4A2FEC3FD6D269EFD8A22D7ECE59EF66E270A114FE587EBA99 |
| frontend/src/lib/realm-owner/r3-project-plan.ts | frontend/src/lib/realm-owner/r3-project-plan.ts | CD4A25350DCD1A845398AF73F2E5027F0ACE766A4E2196AE44551ABE9B8DB9DA |
| frontend/src/components/realm-owner/realm-owner-section-page.tsx | frontend/src/components/realm-owner/realm-owner-section-page.tsx | F5C54A7438E7073D75721A14E1847DE106E5661BCC8544578A96072C3C23312A |
| frontend/src/components/app-shell/surface-config.ts | frontend/src/components/app-shell/surface-config.ts | 54B97805508398ABFA5877C19F26F4B2DEEB8985391AA4C757A3D32570837C72 |
| frontend/src/app/realm/[realm_id]/projects/page.tsx | frontend/src/app/realm/[realm_id]/projects/page.tsx | 3EB9641E4481F8F3ABAF488855EDA317D93E04655E4F2A9130BD1AFE2E300743 |
| frontend/src/app/realm/[realm_id]/execution/page.tsx | frontend/src/app/realm/[realm_id]/execution/page.tsx | 22DD834AE21050FDB395D6218B3F9A3315264BF30C89C1B963D584CDDFFC1382 |
| frontend/next.config.js | frontend/next.config.js | E3D0EC5F335EFD17BE545A47C4DE8F2DC4EDF8E3F65D1D26068FDF97501EC250 |
| frontend/package.json | frontend/package.json | 9F4F6727EC33B2E49837CD167EDA8530FF2E2703F09AEFEED8759B989BC0845B |
| frontend/tests/realm-owner-home/r3-project-plan.test.ts | frontend/tests/realm-owner-home/r3-project-plan.test.ts | C24D835FE0BBE881EF14CD973B0A76188316F59BEF71BD0BFEF58D3F229B41CB |
| frontend/tests/realm-owner-home/adapter.test.ts | frontend/tests/realm-owner-home/adapter.test.ts | 4E3B9DEBFF5469FC033551E6078BD1FEFC964E7F8DD7C41C4205749C422E8677 |
| frontend/tests/realm-owner-home/ts-loader.mjs | frontend/tests/realm-owner-home/ts-loader.mjs | 25425BCB900182079E6C503BD17368826698A1A8A7C7DF89927DA131D97A2110 |
| frontend/tests/public-intake/form.test.ts | frontend/tests/public-intake/form.test.ts | EEF1B608239BF1A9DACDAFAE6A34B9BAB1246F8972ED42F3590C7D5C608E21EC |
| frontend/tests/operations/operations-adapter.test.ts | frontend/tests/operations/operations-adapter.test.ts | 8B3728B43801F19CB5A3F4A2592FD86B865DDCF0FA87D320F5F042F2297DDC0F |
| frontend/scripts/check-v106-preview.mjs | frontend/scripts/check-v106-preview.mjs | 38CB7410AEE8B6463EA5AC259390A3B48A7D43E700AF479B0F66A8A9A2B229F3 |
| frontend/scripts/capture-v106-r4-screenshots.mjs | frontend/scripts/capture-v106-r4-screenshots.mjs | 61A18D533355BB9C85DE0C3D27637341A59A85ED644E69BB0BD2E4A61D512E68 |
| frontend/scripts/capture-v106-r4-real-screenshots.mjs | frontend/scripts/capture-v106-r4-real-screenshots.mjs | 0E4831578B2B103D70565858CF9076F81C3EA656C7A515C234F417FB3DF798A5 |
| frontend/scripts/capture-v106-r3-screenshots.mjs | frontend/scripts/capture-v106-r3-screenshots.mjs | 3B30DAD7900A3A5024C1F481D5518F337AB032F323FDC7871D25521B419CDF94 |
| frontend/scripts/capture-v106-r3-real-screenshots.mjs | frontend/scripts/capture-v106-r3-real-screenshots.mjs | EADAF8569B32182001A349EBB5F550AFFCD27503A7A7ABBD8D2E140824684B4D |
| frontend/scripts/capture-v106-r21-preview-states.mjs | frontend/scripts/capture-v106-r21-preview-states.mjs | 26C8067DCF10FF8F9B05F61F12B6753783B765A1DFBF22972BFB4D2A977C2D40 |
| scripts/verify_v106_r4_package.py | scripts/verify_v106_r4_package.py | F408CB99B8FCAA9EF02031C04FE5BEF87677F89D0E7CA668983363F9C031C82F |
| scripts/verify_v106_r3_fix21_package.py | scripts/verify_v106_r3_fix21_package.py | F651A884557426381E308C71E0D10A2E201146756C9D68AB7EB96844C1B3D2D0 |
| scripts/verify_v106_r3_fix2_package.py | scripts/verify_v106_r3_fix2_package.py | AEFA38C56DE6F27438C4AFF0158026F313B8A592FEDC9BB52947EE10D9101E62 |
| scripts/verify_v106_r3_fix1_package.py | scripts/verify_v106_r3_fix1_package.py | BC6621D99C6E6A47F0B45CED23D0AE90F1D8AE43E4B6C8E48726DB4127DAEA7A |
| docs/generated_images/V10.6-R3-01-projects-empty.png | docs/generated_images/V10.6-R3-01-projects-empty.png | ECE0C5B2FA1193078C931C7D5753DFB9D8D9B4C3B4BDB05989AB4AD8A1FBF3B9 |
| docs/generated_images/V10.6-R3-02-r2-project-enter.png | docs/generated_images/V10.6-R3-02-r2-project-enter.png | FEEF49311A4878255A0ACCDC9535F6901D5C77B889F19C7D1496A05C748F00D5 |
| docs/generated_images/V10.6-R3-14-no-permission.png | docs/generated_images/V10.6-R3-14-no-permission.png | B2F04583A5DF6DE483C37A017F0150B70A28F51C7265F0DB00A8C30B04B76F2C |
| docs/generated_images/V10.6-R3-15-narrow-responsive.png | docs/generated_images/V10.6-R3-15-narrow-responsive.png | 4363165D21409541B11E755E4D46750E929D9759C212ED49233B26D89624FAD0 |
| docs/generated_images/V10.6-R3-REAL-01-projects-page.png | docs/generated_images/V10.6-R3-REAL-01-projects-page.png | 196CFA14696803FD22E9A34C90D1A22222F093C9222148BB2838C572C35C63F4 |
| docs/generated_images/V10.6-R3-REAL-02-tasks-progress-overdue.png | docs/generated_images/V10.6-R3-REAL-02-tasks-progress-overdue.png | 36C42BE1854D09ED8A11ED31596C715CEF2A9AC4622CC8EB8BA2B1F945491AC2 |
| docs/generated_images/V10.6-R3-REAL-03-narrow-responsive.png | docs/generated_images/V10.6-R3-REAL-03-narrow-responsive.png | EFBBD323494339A29A0940EEF3B9C7132B05C765DEED52655C8195455D6AFBCF |
| docs/generated_images/V10.6-R3-REAL-04-no-permission.png | docs/generated_images/V10.6-R3-REAL-04-no-permission.png | F7145EEDBC3352B989F9044BF9AB170D1A7047EBA4B2186D8D8DC42E400791D0 |
| docs/generated_images/V10.6-R3-mock-state-blocked.png | docs/generated_images/V10.6-R3-mock-state-blocked.png | 0EA096E9AEDCC84E3E13C19AF7675D71D0B70ADBD86D5D046E8C84AED367CF93 |
| docs/generated_images/V10.6-R3-mock-state-empty.png | docs/generated_images/V10.6-R3-mock-state-empty.png | ECE0C5B2FA1193078C931C7D5753DFB9D8D9B4C3B4BDB05989AB4AD8A1FBF3B9 |
| docs/generated_images/V10.6-R3-mock-state-error.png | docs/generated_images/V10.6-R3-mock-state-error.png | BDF69EB235E0C645613F442D3D7388AD1FE7E9E4EDD2A174B520380A1450A410 |
| docs/generated_images/V10.6-R3-mock-state-loading.png | docs/generated_images/V10.6-R3-mock-state-loading.png | 33C7A46200F6A2899B04A144D6030A98C939B62F01152AE128892E1962F87B3C |
| docs/generated_images/V10.6-R3-mock-state-no-permission.png | docs/generated_images/V10.6-R3-mock-state-no-permission.png | B2F04583A5DF6DE483C37A017F0150B70A28F51C7265F0DB00A8C30B04B76F2C |
| docs/generated_images/V10.6-R3-mock-state-normal.png | docs/generated_images/V10.6-R3-mock-state-normal.png | FEEF49311A4878255A0ACCDC9535F6901D5C77B889F19C7D1496A05C748F00D5 |
| docs/generated_images/V10.6-R3-mock-state-partial.png | docs/generated_images/V10.6-R3-mock-state-partial.png | F5700E83FA844FCD01489ABB317FE856A861CE3A1951DAB5B466C1218DA6928A |
| docs/generated_images/V10.6-R4-01-issue-workbench.png | docs/generated_images/V10.6-R4-01-issue-workbench.png | 21C5521398C5E7DACBF04C7EAC6E685C2EC6A46D79EBDA0931B6BBAB21D52B9B |
| docs/generated_images/V10.6-R4-02-narrow-responsive.png | docs/generated_images/V10.6-R4-02-narrow-responsive.png | 52B76574CB6B91FBC3C6B19A9395D722B8CFDE2FCBC5C5845561BDDE8D468D3C |
| docs/generated_images/V10.6-R4-REAL-01-issue-workbench.png | docs/generated_images/V10.6-R4-REAL-01-issue-workbench.png | 522D73D3895747B56DB16F56A78431875692ABF05E8974672CD005105ACD4CA8 |
| docs/generated_images/V10.6-R4-REAL-02-skill-draft.png | docs/generated_images/V10.6-R4-REAL-02-skill-draft.png | D74741DC395ED7155454D73C3773898120DA7D43D5DEFFD46D6C348672776D97 |
| docs/generated_images/V10.6-R4-REAL-03-narrow-responsive.png | docs/generated_images/V10.6-R4-REAL-03-narrow-responsive.png | F918C337426D52F9CD502F5B0CDD9976FCD4D0CF5EAEEE581EADA10A85B08270 |
| docs/generated_images/V10.6-R4-REAL-04-no-permission.png | docs/generated_images/V10.6-R4-REAL-04-no-permission.png | 8E01D8589535F85DCFC6BDB6128DB5715D7B3844ADED7E2F640C303BAF346983 |
| docs/generated_images/V10.6-R4-mock-state-blocked.png | docs/generated_images/V10.6-R4-mock-state-blocked.png | 59CA3D6C37B0562961106105C16EC451AE5C37D05B5C8CA46219FF7F82C53CD2 |
| docs/generated_images/V10.6-R4-mock-state-empty.png | docs/generated_images/V10.6-R4-mock-state-empty.png | 9ABB80219B896D923D41EA0D14A962B60E7653647A0D7F5952DAC1C134838C91 |
| docs/generated_images/V10.6-R4-mock-state-error.png | docs/generated_images/V10.6-R4-mock-state-error.png | E12C6C8F37D4E30336061FBE0BCC0A905E7E84953C0B38AC8EE41E60B127A376 |
| docs/generated_images/V10.6-R4-mock-state-loading.png | docs/generated_images/V10.6-R4-mock-state-loading.png | 505B8D8604107D99C4F4FEB0147E85098B23AB813330169A3EFFC0C16ABA966F |
| docs/generated_images/V10.6-R4-mock-state-no-permission.png | docs/generated_images/V10.6-R4-mock-state-no-permission.png | 62E260C218351B663F925465C8A4849D2F7BE4DB5A0938C0AEDB788DE96465B1 |
| docs/generated_images/V10.6-R4-mock-state-normal.png | docs/generated_images/V10.6-R4-mock-state-normal.png | 5D1D3A822457404FC5EFAFA34EA3E37C61FBE25E9DA3486088B4588C5ACF209C |
| docs/generated_images/V10.6-R4-mock-state-partial.png | docs/generated_images/V10.6-R4-mock-state-partial.png | 3A39FBD38B18452A16003C652CB71A629B7CBD396641C1ADDAB1F8ECF449596B |

## 测试结果摘要

- 后端全量：351 passed。
- R4 专项：18 passed。
- 前端测试：25 passed。
- TypeScript：通过。
- lint：通过，仅仓库原有 4 项 warning。
- production build：通过，54 个路由。
- 预览检查：PASS pages=36 meta=36 customerStates=7 projectStates=7 issueStates=7。
- 交付包自检：PASS。

## 未完成项

- R5、能力市场、行业态势、今日工作未开发。
- 外部 AI Provider 接入未在本轮启用，本地规则明确标记 rule_based。

## 已知风险

- Skill 草稿为恒域世界内部业务资产，不等于系统级 SKILL.md。
- 提醒只做本地记录，不发送外部消息。

## 敏感信息检查结果

- 未包含 `.env`。
- 未包含 Token、API Key、客户隐私或数据库转储。
- 截图来自脱机 Mock 与隔离 fixture 环境。
