import { chromium } from "file:///C:/Users/27195/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs";
import { readFileSync } from "node:fs";
import path from "node:path";

const previewPath = path.resolve("..", "docs", "v106-all-pages-design-preview.html");
const html = readFileSync(previewPath, "utf8");
const browser = await chromium.launch({
  executablePath: "C:/Program Files/Google/Chrome/Application/chrome.exe",
  headless: true,
  args: ["--disable-gpu", "--no-sandbox"],
});

const errors = [];
let page;
try {
  page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  page.on("console", (message) => {
    if (message.type() === "error") errors.push(message.text());
  });
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto("file:///" + previewPath.replace(/\\/g, "/"), { waitUntil: "load" });

  const counts = await page.evaluate(() => ({
    pages: SURFACES.flatMap((s) => s.pages).length,
    metaKeys: Object.keys(PAGE_META).length,
    metaEntries: Object.keys(PAGE_META).filter((key) => key !== "default").length,
    stateButtons: document.querySelectorAll(".state-switcher button[data-state]").length,
  }));

  if (counts.pages !== 36) throw new Error(`36 pages expected, got ${counts.pages}`);
  if (counts.metaEntries < 36) throw new Error(`page metadata incomplete: ${counts.metaEntries}`);

  await page.getByRole("button", { name: "客户与定位", exact: true }).click();
  await page.waitForTimeout(50);
  const stateCount = await page.locator(".state-switcher button[data-state]").count();
  if (stateCount !== 7) throw new Error(`expected 7 customer mock states, got ${stateCount}`);
  for (const state of ["loading", "empty", "partial", "blocked", "error", "no-permission", "normal"]) {
    await page.locator(`.state-switcher button[data-state="${state}"]`).click();
    await page.waitForTimeout(20);
    const visible = await page.locator(`text=${state}`).first().isVisible();
    if (!visible) throw new Error(`mock state ${state} not visible`);
  }

  const forbidden = [
    "全部来自真实 API",
    "真实运行记录",
    "真实项目",
    "前端应用面",
  ];
  const found = forbidden.filter((text) => html.includes(text));
  if (found.length > 0) throw new Error(`forbidden preview wording: ${found.join(", ")}`);
  if (!html.includes("脱机设计预览 / 非生产数据 / Mock")) throw new Error("missing offline/mock label");
  if (!html.includes("内部架构设计视图")) throw new Error("missing internal architecture marker");
  if (errors.length > 0) throw new Error(`console/page errors: ${errors.join(" | ")}`);

  const narrow = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await narrow.goto("file:///" + previewPath.replace(/\\/g, "/"), { waitUntil: "load" });
  const overflow = await narrow.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    client: document.documentElement.clientWidth,
  }));
  if (overflow.scroll > overflow.client + 1) {
    throw new Error(`narrow overflow: ${overflow.scroll} > ${overflow.client}`);
  }
  await narrow.close();

  console.log(`PASS preview pages=${counts.pages} meta=${counts.metaEntries} customerStates=${stateCount} narrow=ok errors=0`);
} finally {
  await browser.close();
}
