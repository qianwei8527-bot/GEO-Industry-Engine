# GEO产业发展趋势与职业生态模型

> 第三个认知层：这个产业怎么发展？谁参与？谁赚钱？产生哪些岗位？

> **内部定位：GEO产业认知库** — 不只是存数据的数据库，而是包含趋势推理、职业图谱、商业机会分析的认知资产库。

---

## 一、为什么要研究GEO产业发展？

### 1.1 以前系统的盲区

现有的GEO产业导航系统有：行业地图、企业地图、服务商地图。但是缺少：产业演进规律、职业体系、能力体系、人才供需、商业机会。

### 1.2 为什么现在补正合适

前两个认知层刚建好，三个认知层构成完整底层数据三角：
- 1号 AI模型智能库：AI怎么工作？
- 2号 用户行为与决策路径：人为什么问？AI为什么推？
- 3号 产业趋势与职业生态：产业怎么发展？谁参与？谁赚钱？

---

## 二、GEO产业生命周期

### 2.1 三阶段模型

**萌芽期（2023-2024）**
- AI搜索出现，SEO从业者开始关注GEO
- 第一批GEO工具出现，没有标准和方法论

**形成期（2025-2027）← 我们现在在这里**
- GEO成为企业数字营销标准配置
- GEO SaaS工具成熟，职业岗位正式出现
- 认证体系建立，AI搜索市场份额达30%+
- 企业设GEO预算（营销预算的5-15%）

**基础设施期（2028+）**
- AI可见度成为企业基础能力（今天的SEO）
- GEO Agent自动优化成为标配
- AI搜索占搜索总量50%+

### 2.2 对平台的意义

| 阶段 | 平台策略 | 收入形式 |
|------|---------|---------|
| 萌芽期 | 建立标准、抢占心智 | 免费工具+品牌建设 |
| 形成期 | 建设市场、撮合交易 | SaaS+佣金 |
| 基础设施期 | 数据垄断、API输出 | API+私有部署+Agent SaaS |

---

## 三、GEO市场趋势

| 指标 | 2024 | 2025(估) | 2027(估) | 2030(估) |
|------|------|---------|---------|---------|
| TAM（全球潜在市场） | 50亿 | 120亿 | 300亿 | 800亿 |
| SAM（可服务市场） | 10亿 | 30亿 | 80亿 | 200亿 |
| SOM（可获得市场） | 1亿 | 5亿 | 15亿 | 40亿 |

数据来源：行业报告+公开数据+平台估算。

### 技术趋势

| 技术方向 | 对GEO的影响 | 时间线 |
|---------|-----------|-------|
| AI Search | GEO核心入口 | 现在 |
| Agent Search | GEO需针对Agent优化 | 2025-2026 |
| Multi-Agent协作 | GEO需同时被多个Agent推荐 | 2026-2027 |
| RAG+企业知识库 | 知识资产成为GEO新战场 | 现在-2026 |
| AI Shopping | 产品GEO新场景 | 2025-2027 |

---

## 四、商业模式演进（4代）

**第一代：GEO咨询（现在）**
项目制，顾问驱动。客单价5-50万/项目，利润率40-60%。

**第二代：GEO SaaS（2025-2026）**
订阅制，工具驱动。客单价1000-10万/年，利润率70-80%。

**第三代：GEO Agent（2026-2027）**
自动化，AI驱动。客单价1-50万/年，利润率60-75%。蓝海市场。

**第四代：AI品牌基础设施（2028+）**
基础设施，数据驱动。客单价5-200万/年，利润率80%+。

---

## 五、GEO产业链地图

**上游：AI基础设施**
- 大模型提供商（OpenAI、Google、Anthropic、DeepSeek等）
- AI搜索平台（ChatGPT Search、Perplexity、Gemini等）
- Agent平台（LangChain、AutoGen等）

**中游：GEO技术服务**
- GEO SaaS平台
- AI内容优化工具
- 知识图谱构建服务
- GEO咨询与策略
- GEO认证与培训

**下游：应用企业**
- 企业品牌、电商平台、制造业、服务业
- 投资机构、政府/园区、教育/研究

---

## 六、GEO岗位体系（7个核心岗位）

### 6.1 GEO战略顾问
对标SEO顾问升级版。职责：企业AI搜索战略、GEO路线图。
技能：市场分析、AI搜索理解、商业咨询。
薪资：30-80K/月。需求量：★★★★ 高。

### 6.2 GEO运营经理
对标SEO运营。职责：Prompt监控、AI排名监测、内容策略。
技能：数据分析、内容策略、项目管理。
薪资：15-40K/月。需求量：★★★★★ 最高。

### 6.3 GEO内容工程师
新职业，无直接对标。职责：设计AI容易理解、引用、推荐的内容。
技能：LLM理解、内容结构化、Schema、知识图谱。
薪资：20-60K/月。需求量：★★★★★ 极强。

### 6.4 GEO数据分析师
职责：分析AI回答数据、品牌曝光、竞争格局。
技能：SQL、Python、数据分析、AI工具。
薪资：20-50K/月。需求量：★★★★ 高。

### 6.5 GEO技术工程师
职责：GEO监控系统、API、数据管道、Agent。
技能：Python、API开发、数据工程、AI Agent。
薪资：30-70K/月。需求量：★★★★ 高。

### 6.6 AI品牌资产工程师
新职业，未来重要。职责：管理企业数字身份、知识库、AI描述、实体关系。
技能：知识图谱、内容架构、品牌管理。
薪资：25-65K/月。需求量：★★★ 增长最快。

### 6.7 GEO Agent运营师
未来新岗位。职责：管理AI Agent团队、设计Workflow。
技能：Agent理解、Workflow设计、Prompt工程。
薪资：25-55K/月。需求量：★★★ 随Agent普及增长。

---

## 七、GEO技能体系

### 技能等级模型

| 等级 | 定义 | GEO运营师示例 |
|------|------|-------------|
| L1 助手 | 能使用工具完成任务 | 会用GEO工具查看评分 |
| L2 执行者 | 能独立完成日常任务 | 能独立分析AI排名 |
| L3 专家 | 能制定策略指导他人 | 能制定行业GEO策略 |
| L4 领袖 | 能设计体系制定标准 | 能设计企业GEO增长体系 |

---

## 八、人才成长路径

**路径A（运营方向 需求量最大）**
GEO运营助理(L1) -> 专员(L2) -> 经理(L3) -> 总监(L4)

**路径B（技术方向 薪资最高）**
GEO技术工程师(L2) -> 技术专家(L3) -> 技术架构师(L4)

**路径C（咨询方向 影响力最大）**
GEO分析师(L1) -> 顾问(L2) -> 高级顾问(L3) -> 战略负责人(L4)

**路径D（AI内容方向 增长最快）**
内容助理(L1) -> GEO内容工程师(L2) -> 品牌资产工程师(L3) -> 品牌架构师(L4)

---

## 九、企业能力需求模型

| GEO成熟度 | 需人才 | 预算规模 |
|----------|-------|---------|
| L1未入局 | 不需要 | 0 |
| L2被动 | 1名专员+外部顾问 | 10-30万/年 |
| L3主动 | 2-3人团队 | 30-80万/年 |
| L4系统 | 5-10人团队 | 80-200万/年 |
| L5引领 | 10+人团队 | 200万+/年 |

---

## 十、与现有系统的连接

- 产业导航系统：产业链地图、职业体系、技能体系数据来源
- 交易市场：人才/岗位分类、企业需求匹配
- 认证体系：技能认证(L1-L4)、岗位能力认证
- Agent OS：Industry Agent负责产业趋势分析、岗位需求预测

---

## 十一、领域对象设计

### GEOJob（GEO岗位）
- id (UUID, PK)
- name (String) - 岗位名称
- category (Enum: strategy/operation/content/data/engineering/brand/agent)
- level (Enum: L1/L2/L3/L4)
- description (Text)
- typical_tasks (JSON)
- salary_range (JSON)
- demand_level (Int, 1-5)

### GEOJobSkill（岗位技能）
- id (UUID, PK)
- job_id (UUID, FK -> GEOJob)
- skill_name (String)
- skill_category (Enum: cognitive/data/content/engineering/strategy/tools)
- required_level (Int, 1-5)
- learning_path (JSON)

### GEOCareerPath（职业路径）
- id (UUID, PK)
- from_job_id (UUID, FK -> GEOJob)
- to_job_id (UUID, FK -> GEOJob)
- path_type (Enum: promotion/transition/specialization)
- typical_duration (String)
- required_experience (String)

### GEOIndustryTrend（产业趋势）

| 属性 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| trend_name | String | 趋势名称 |
| trend_category | Enum | technology/market/business_model/policy |
| industry_id | UUID | FK -> Industry |
| time_horizon | String | 时间范围（2025/2027/2030）|
| impact_level | Int | 影响程度(1-5) |
| description | Text | 趋势描述 |
| evidence | JSON | 支撑证据 |
| confidence | Decimal | 置信度 |
| data_period | Date | |

### TalentDemand（人才需求）

| 属性 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| role_id | UUID | FK -> GEOJob |
| industry_id | UUID | FK -> Industry |
| demand_count | Int | 需求量 |
| demand_growth | Decimal | 需求增长率 |
| avg_salary | Decimal | 平均薪资 |
| skill_gap | JSON | 技能缺口分析 |
| data_period | Date | |

### BusinessOpportunity（商业机会）

| 属性 | 类型 | 说明 |
|------|------|------|
| id | UUID | 主键 |
| industry_id | UUID | FK -> Industry |
| opportunity_type | Enum | service_gap/talent_shortage/market_entry/technology_adoption |
| description | Text | 机会描述 |
| potential_value | Decimal | 预估价值 |
| entry_barrier | Enum | low/medium/high |
| time_window | String | 时间窗口 |
| confidence | Decimal | 置信度 |

---

## 关联文档

| 文档 | 关系 |
|------|------|
| 02_领域模型设计.md | GEOJob/GEOJobSkill/GEOCareerPath 领域对象定义 |
| 03_数据架构.md | 相关数据表 |
| 01_产品架构PRD.md | 产业导航系统职业生态模块 |
