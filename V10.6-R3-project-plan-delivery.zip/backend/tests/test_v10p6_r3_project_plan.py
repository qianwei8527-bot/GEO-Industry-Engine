"""V10.6-R3 project plan workflow tests."""

import asyncio
import concurrent.futures
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import settings
from app.core.security import create_access_token
from app.database import _get_session_factory
from app.main import app
from app.models.company import Company
from app.models.entity import Entity
from app.models.evidence import Evidence
from app.models.geo_project import GeoProject, ProjectArtifact, ProjectWorkItem
from app.models.governance import AuditLog, NodeMembership
from app.models.intake import ClientIntake, IntakeAnalysis
from app.models.realm import RealmRegistry
from app.models.reputation import Reputation
from app.models.user import User, UserRole
from app.services.geo_project_service import get_geo_project_service
from app.services.intake_service import get_intake_service
from app.services.project_plan_service import PlanStateError, get_project_plan_service
from app.services.realm_service import get_realm_service


def make_user(db, email, role=UserRole.ENTERPRISE):
    user = User(email=email, password_hash="x", name="域主", role=role)
    db.add(user)
    return user


async def _setup_realm(db, user, name):
    ws = await get_realm_service().create_enterprise(db, user, {
        "name": name,
        "website": f"https://{uuid.uuid4().hex[:8]}.test",
    })
    entity_id = uuid.UUID(ws["identity"]["id"])
    registry = (await db.execute(
        select(RealmRegistry).where(RealmRegistry.entity_id == entity_id)
    )).scalars().first()
    return entity_id, registry.id


async def _create_analyzed_intake(db, user, entity_id, text=None):
    svc = get_intake_service()
    intake = await svc.create_intake(db, user, str(entity_id), {
        "pasted_text": text or (
            "品牌名称：R3测试品牌\n"
            "企业主体：R3测试企业有限公司\n"
            "产品：R3测试服务\n"
            "问题：从零开始建立GEO认知\n"
        ),
        "files": [],
    })
    await svc.analyze_intake(db, user, intake["id"])
    return intake["id"]


async def _create_confirmed_project(db, owner, entity_id):
    svc = get_intake_service()
    intake_id = await _create_analyzed_intake(db, owner, entity_id)
    await svc.start_review(db, owner, intake_id)
    await svc.update_profile(db, owner, intake_id, {"target_customer": "R3行业客户"})
    await svc.confirm_profile(db, owner, intake_id)
    draft = await svc.generate_positioning(db, owner, intake_id)
    confirmed = await svc.confirm_positioning(
        db, owner, intake_id,
        {"priority_direction": "先补齐行业赛道"},
        expected_version=draft["version"],
    )
    project = await get_geo_project_service().create_project_from_positioning(
        db, owner, intake_id, confirmed=True,
        expected_position_version=confirmed["metadata_json"]["positioning_version"],
    )
    return project, intake_id


async def _cleanup(db, entity_ids, user_ids, intake_ids=(), project_ids=()):
    for pid in project_ids:
        await db.execute(delete(ProjectWorkItem).where(ProjectWorkItem.project_id == pid))
        await db.execute(delete(ProjectArtifact).where(ProjectArtifact.project_id == pid))
        await db.execute(delete(GeoProject).where(GeoProject.id == pid))
    for intake_id in intake_ids:
        await db.execute(delete(IntakeAnalysis).where(IntakeAnalysis.intake_id == intake_id))
        await db.execute(delete(ClientIntake).where(ClientIntake.id == intake_id))
    for entity_id in entity_ids:
        registry = (await db.execute(
            select(RealmRegistry).where(RealmRegistry.entity_id == entity_id)
        )).scalars().first()
        if registry:
            intakes = (await db.execute(
                select(ClientIntake).where(ClientIntake.realm_id == registry.id)
            )).scalars().all()
            for intake in intakes:
                await db.execute(delete(IntakeAnalysis).where(IntakeAnalysis.intake_id == intake.id))
                await db.execute(delete(ClientIntake).where(ClientIntake.id == intake.id))
            projects = (await db.execute(
                select(GeoProject).where(GeoProject.realm_id == registry.id)
            )).scalars().all()
            for project in projects:
                await db.execute(delete(ProjectWorkItem).where(ProjectWorkItem.project_id == project.id))
                await db.execute(delete(ProjectArtifact).where(ProjectArtifact.project_id == project.id))
                await db.execute(delete(GeoProject).where(GeoProject.id == project.id))
            await db.execute(delete(RealmRegistry).where(RealmRegistry.entity_id == entity_id))
        await db.execute(delete(Evidence).where(Evidence.entity_id == entity_id))
        await db.execute(delete(Reputation).where(Reputation.node_id == entity_id))
        await db.execute(delete(NodeMembership).where(NodeMembership.node_id == str(entity_id)))
        await db.execute(delete(Company).where(Company.id == entity_id))
        await db.execute(delete(Entity).where(Entity.id == entity_id))
    for user_id in user_ids:
        await db.execute(delete(User).where(User.id == user_id))
    await db.commit()


class TestProjectPlan:
    async def test_r2_project_enters_plan_and_draft_is_deterministic(self):
        factory = _get_session_factory()
        async with factory() as db:
            owner = make_user(db, f"r3-owner-{uuid.uuid4().hex[:8]}@x.com")
            db.add(owner)
            await db.commit()
            await db.refresh(owner)
            entity_id, registry_id = await _setup_realm(db, owner, "R3计划域")
            intake_ids = []
            project_ids = []
            try:
                project, intake_id = await _create_confirmed_project(db, owner, entity_id)
                intake_ids.append(uuid.UUID(intake_id))
                project_ids.append(uuid.UUID(project["id"]))

                svc = get_project_plan_service()
                sources = await svc.list_workflow_sources(db, owner)
                assert any(s["source_type"] == "platform_seed" and not s["owner_confirmed"] for s in sources["workflow_sources"])
                view = await svc.generate_plan(
                    db, owner, project["id"], "platform_seed", "platform-seed-geo-starter"
                )
                assert view["plan_status"] == "plan_draft"
                assert view["plan_version"] == 1
                assert view["source_type"] == "platform_seed"
                assert view["unknown_items"]
                assert "task_owners_unassigned" in view["unknown_items"]
                assert view["versions"][0]["content_json"]["truth_scope"] == "inferred"
                assert all(t.get("owner_id") is None for t in view["tasks"])
                assert all(t.get("start_at") is None for t in view["tasks"])

                project2, intake2 = await _create_confirmed_project(db, owner, entity_id)
                intake_ids.append(uuid.UUID(intake2))
                project_ids.append(uuid.UUID(project2["id"]))
                view2 = await svc.generate_plan(db, owner, project2["id"], "platform_seed", "platform-seed-geo-starter")
                assert view["plan_hash"] == view2["plan_hash"]
                with pytest.raises(PlanStateError):
                    await svc.generate_plan(db, owner, project["id"], "platform_seed", "platform-seed-geo-starter")
            finally:
                await _cleanup(db, [entity_id], [owner.id], intake_ids, project_ids)

    async def test_confirm_requires_owner_and_generates_tasks_once(self):
        factory = _get_session_factory()
        async with factory() as db:
            owner = make_user(db, f"r3-confirm-{uuid.uuid4().hex[:8]}@x.com")
            editor = make_user(db, f"r3-editor-{uuid.uuid4().hex[:8]}@x.com", role=UserRole.ENTERPRISE)
            db.add_all([owner, editor])
            await db.commit()
            await db.refresh(owner)
            await db.refresh(editor)
            entity_id, _ = await _setup_realm(db, owner, "R3确认域")
            intake_ids = []
            project_ids = []
            try:
                project, intake_id = await _create_confirmed_project(db, owner, entity_id)
                intake_ids.append(uuid.UUID(intake_id))
                project_ids.append(uuid.UUID(project["id"]))
                svc = get_project_plan_service()
                await svc.generate_plan(db, owner, project["id"], "platform_seed", "platform-seed-geo-starter")

                with pytest.raises(ValueError, match="显式确认"):
                    await svc.confirm_plan(db, owner, project["id"], False, 1)
                with pytest.raises(ValueError, match="版本已变化"):
                    await svc.confirm_plan(db, owner, project["id"], True, 99)

                confirmed = await svc.confirm_plan(db, owner, project["id"], True, 1)
                assert confirmed["plan_status"] == "plan_confirmed"
                task_count = len(confirmed["tasks"])
                assert task_count > 0
                assert all(t["status"] == "planned" for t in confirmed["tasks"])

                again = await svc.confirm_plan(db, owner, project["id"], True, 1)
                assert len(again["tasks"]) == task_count
                rows = (await db.execute(
                    select(ProjectWorkItem).where(ProjectWorkItem.project_id == uuid.UUID(project["id"]))
                )).scalars().all()
                assert len(rows) == task_count
                artifact = (await db.execute(
                    select(ProjectArtifact)
                    .where(ProjectArtifact.project_id == uuid.UUID(project["id"]))
                    .order_by(ProjectArtifact.created_at.desc())
                )).scalars().first()
                assert artifact.truth_status == "observed"
                assert artifact.content_json["truth_scope"] == "inferred"
                audit = (await db.execute(
                    select(AuditLog).where(AuditLog.action == "project_plan_confirmed")
                )).scalars().all()
                assert audit
                assert "verified" not in str(audit[-1].metadata_json)
            finally:
                await _cleanup(db, [entity_id], [owner.id, editor.id], intake_ids, project_ids)

    async def test_draft_edit_version_conflict_and_validation(self):
        factory = _get_session_factory()
        async with factory() as db:
            owner = make_user(db, f"r3-edit-{uuid.uuid4().hex[:8]}@x.com")
            db.add(owner)
            await db.commit()
            await db.refresh(owner)
            entity_id, _ = await _setup_realm(db, owner, "R3编辑域")
            intake_ids = []
            project_ids = []
            try:
                project, intake_id = await _create_confirmed_project(db, owner, entity_id)
                intake_ids.append(uuid.UUID(intake_id))
                project_ids.append(uuid.UUID(project["id"]))
                svc = get_project_plan_service()
                view = await svc.generate_plan(db, owner, project["id"], "platform_seed", "platform-seed-geo-starter")
                tasks = list(view["versions"][0]["content_json"]["tasks"])
                tasks[0]["start_at"] = datetime.now(timezone.utc).isoformat()
                tasks[0]["due_at"] = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
                tasks[1]["depends_on"] = [tasks[0]["task_key"]]

                edited = await svc.update_draft(
                    db, owner, project["id"], 1,
                    {"tasks": tasks, "phases": view["versions"][0]["content_json"]["phases"]},
                )
                assert edited["plan_version"] == 2
                with pytest.raises(ValueError, match="版本已变化"):
                    await svc.update_draft(
                        db, owner, project["id"], 1,
                        {"tasks": tasks},
                    )

                bad = list(tasks)
                bad[0]["due_at"] = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
                with pytest.raises(ValueError, match="due_at"):
                    await svc.update_draft(db, owner, project["id"], 2, {"tasks": bad})

                tasks[0]["due_at"] = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
                cyclic = list(tasks)
                cyclic[1]["depends_on"] = [cyclic[0]["task_key"]]
                cyclic[0]["depends_on"] = [cyclic[1]["task_key"]]
                with pytest.raises(ValueError, match="cycle"):
                    await svc.update_draft(db, owner, project["id"], 2, {"tasks": cyclic})

                completed_bad = list(tasks)
                completed_bad[0]["status"] = "completed"
                completed_bad[0]["progress"] = 50
                with pytest.raises(ValueError, match="progress 100"):
                    await svc.update_draft(db, owner, project["id"], 2, {"tasks": completed_bad})

                version_count = (await db.execute(
                    select(ProjectArtifact).where(ProjectArtifact.project_id == uuid.UUID(project["id"]))
                )).scalars().all()
                assert len(version_count) == 2
            finally:
                await _cleanup(db, [entity_id], [owner.id], intake_ids, project_ids)

    async def test_cross_realm_api_is_anti_enumeration(self):
        factory = _get_session_factory()
        async with factory() as db:
            owner = make_user(db, f"r3-api-owner-{uuid.uuid4().hex[:8]}@x.com")
            outsider = make_user(db, f"r3-api-out-{uuid.uuid4().hex[:8]}@x.com")
            db.add_all([owner, outsider])
            await db.commit()
            await db.refresh(owner)
            await db.refresh(outsider)
            entity_id, _ = await _setup_realm(db, owner, "R3隔离域")
            intake_ids = []
            project_ids = []
            try:
                project, intake_id = await _create_confirmed_project(db, owner, entity_id)
                intake_ids.append(uuid.UUID(intake_id))
                project_ids.append(uuid.UUID(project["id"]))
                owner_token = create_access_token(owner.id)
                outsider_token = create_access_token(outsider.id)
                endpoints = [
                    ("GET", f"/api/v1/project-plans/{project['id']}", None),
                    ("POST", f"/api/v1/project-plans/{project['id']}/generate", {}),
                    ("PUT", f"/api/v1/project-plans/{project['id']}/draft", {"expected_version": 1, "plan": {}}),
                    ("POST", f"/api/v1/project-plans/{project['id']}/confirm", {"confirmed": True, "expected_version": 1}),
                    ("GET", f"/api/v1/project-plans/{project['id']}/export.csv", None),
                ]
                missing_id = str(uuid.uuid4())
                async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
                    for method, path, body in endpoints:
                        out_resp = await client.request(method, path, headers={"Authorization": f"Bearer {outsider_token}"}, json=body)
                        missing_resp = await client.request(
                            method, path.replace(project["id"], missing_id),
                            headers={"Authorization": f"Bearer {owner_token}"}, json=body,
                        )
                        assert out_resp.status_code == 404, (method, path, out_resp.status_code, out_resp.text)
                        assert missing_resp.status_code == 404, (method, path, missing_resp.status_code, missing_resp.text)
                        assert out_resp.json()["detail"] == "resource not found"
                        assert missing_resp.json()["detail"] == "resource not found"
            finally:
                await _cleanup(db, [entity_id], [owner.id, outsider.id], intake_ids, project_ids)

    async def test_task_progress_reminder_and_plan_completion(self):
        factory = _get_session_factory()
        async with factory() as db:
            owner = make_user(db, f"r3-progress-{uuid.uuid4().hex[:8]}@x.com")
            db.add(owner)
            await db.commit()
            await db.refresh(owner)
            entity_id, _ = await _setup_realm(db, owner, "R3进度域")
            intake_ids = []
            project_ids = []
            try:
                project, intake_id = await _create_confirmed_project(db, owner, entity_id)
                intake_ids.append(uuid.UUID(intake_id))
                project_ids.append(uuid.UUID(project["id"]))
                svc = get_project_plan_service()
                await svc.generate_plan(db, owner, project["id"], "platform_seed", "platform-seed-geo-starter")
                confirmed = await svc.confirm_plan(db, owner, project["id"], True, 1)
                first = confirmed["tasks"][0]
                with pytest.raises(ValueError, match="progress"):
                    await svc.update_task(db, owner, project["id"], first["id"], {"progress": 120})
                active = await svc.update_task(
                    db, owner, project["id"], first["id"], {"status": "in_progress", "progress": 50}
                )
                assert active["plan_status"] == "plan_active"

                task_row = (await db.execute(
                    select(ProjectWorkItem).where(ProjectWorkItem.id == uuid.UUID(first["id"]))
                )).scalars().first()
                task_row.due_at = datetime.now(timezone.utc) - timedelta(days=1)
                task_row.reminder_at = datetime.now(timezone.utc) - timedelta(hours=1)
                await db.commit()
                view = await svc.list_plan(db, owner, project["id"])
                assert any(r["type"] == "overdue" for r in view["reminders"])

                for task in view["tasks"]:
                    await svc.update_task(db, owner, project["id"], task["id"], {"status": "completed", "progress": 100})
                done = await svc.list_plan(db, owner, project["id"])
                assert done["plan_status"] == "plan_completed"
            finally:
                await _cleanup(db, [entity_id], [owner.id], intake_ids, project_ids)

    async def test_csv_export_and_concurrent_confirm(self):
        factory = _get_session_factory()
        async with factory() as db:
            owner = make_user(db, f"r3-csv-{uuid.uuid4().hex[:8]}@x.com")
            db.add(owner)
            await db.commit()
            await db.refresh(owner)
            entity_id, _ = await _setup_realm(db, owner, "R3导出域")
            entity_id_uuid = entity_id
            owner_id = owner.id
            owner_email = owner.email
            intake_ids = []
            project_ids = []
            try:
                project, intake_id = await _create_confirmed_project(db, owner, entity_id)
                intake_ids.append(uuid.UUID(intake_id))
                project_ids.append(uuid.UUID(project["id"]))
                project_id = project["id"]
                svc = get_project_plan_service()
                await svc.generate_plan(db, owner, project_id, "platform_seed", "platform-seed-geo-starter")

                def confirm_worker(label):
                    async def inner():
                        engine = create_async_engine(settings.DATABASE_URL)
                        local_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
                        try:
                            async with local_factory() as session:
                                actor = User(id=owner_id, email=owner_email, password_hash="x", name="域主", role=UserRole.ENTERPRISE)
                                try:
                                    await get_project_plan_service().confirm_plan(session, actor, project_id, True, 1)
                                    return ("ok", label)
                                except Exception as exc:
                                    return ("error", type(exc).__name__, str(exc))
                        finally:
                            await engine.dispose()
                    return asyncio.run(inner())

                with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                    futures = [pool.submit(confirm_worker, "A"), pool.submit(confirm_worker, "B")]
                    results = [f.result(timeout=30) for f in futures]
                assert all(r[0] == "ok" for r in results)
                rows = (await db.execute(
                    select(ProjectWorkItem).where(ProjectWorkItem.project_id == uuid.UUID(project_id))
                )).scalars().all()
                assert len(rows) > 0
                versions = [(row.metadata_json or {}).get("plan_version") for row in rows]
                assert len(set(versions)) == 1

                csv_text = await svc.export_plan_csv(db, owner, project_id)
                assert csv_text.startswith("\ufeff")
                assert "task_key" in csv_text
                assert project["name"] not in csv_text or "R3导出域" not in csv_text
            finally:
                await _cleanup(db, [entity_id_uuid], [owner_id], intake_ids, project_ids)
