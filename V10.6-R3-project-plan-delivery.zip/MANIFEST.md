# V10.6-R3 项目与执行计划交付 MANIFEST

- 任务编号：V10.6-R3-PROJECT-PLAN
- 前置状态：V10.6-R1、V10.6-R2/R2.1 已冻结
- 是否允许部署：否
- 是否允许提交或推送：否
- 交付包：V10.6-R3-project-plan-delivery.zip

## 文件清单（ZIP 路径 / 仓库源路径 / SHA-256）

`MANIFEST.md` 为本清单文件，不计算自身哈希；ZIP 内路径全部为 ASCII。

| ZIP路径（ASCII） | 仓库源路径 | SHA-256 |
| --- | --- | --- |
| docs/17-8_V10.6-R3-project-plan-execution-report.md | docs/17-8_V10.6-R3-project-plan-execution-report.md | 6BC151AE93971A1DE595AD92BAEE29D1A5BD8B7C2103828BCD972C7B34B6198B |
| docs/V10.6-R3-code-change-list.md | docs/V10.6-R3-code-change-list.md | 25A3057B2013D80F8369E99C88D5D5F87904E844D7C7C5E8525B8BE161151F62 |
| docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | ECFB32AE6FDC63C703DE2B123F5189F29DAB9CAB48230B3F83E9048147BE34A8 |
| docs/17-6_V10.6-R2.1-FIX1-acceptance-correction-report.md | docs/17-6_V10.6-R2.1-FIX1验收修正执行报告.md | 9195D3DEE54F605340138890962A93A3EE32553B718D50E18250B070F97D3558 |
| docs/17-5_V10.6-R2.1-UI-delivery-closeout-report.md | docs/17-5_V10.6-R2.1UI同步与交付收口执行报告.md | 5F17C384B0EA7FD9A7DE373326D35E7E0A20139F059294EFBE8D1092C0EB1D0C |
| docs/17-4_V10.6-R2-client-positioning-report.md | docs/17-4_V10.6-R2客户与定位执行报告.md | 03D6D1AF5E2C25DD3AB7E863A9C405D5606907004E46EA67AE6A2C59A2741461 |
| docs/v106-all-pages-design-preview.html | docs/v106-all-pages-design-preview.html | B82D2E3901AB4825732BB7423C2D751A167998F23CC7BEEFEE411046E4F803E8 |
| docs/V10.6-UI-SYNC-PROTOCOL.md | docs/V10.6-UI-SYNC-PROTOCOL.md | F4CF4D1471902F131DEED0F6D9F6AC86E6BC0C5B7B810D8D04DF59373A7EFA84 |
| docs/V10.6-R2.1-code-change-list.md | docs/V10.6-R2.1-代码变更清单.md | EE1D81B1821805DD86B40C0EA9F1E124776899283EC919CE54E00F8D8C087635 |
| docs/18-3-page-integration-list.md | docs/18-3_页面整合清单.md | FB29908D3C7CB9385881F6E0F6D1248D85B4B83EB66DD3495F35FF77F20AF93E |
| config/universe/project_plan.yaml | config/universe/project_plan.yaml | 1CB3AE37B005FDDDA225B23BA517D639EE186EB2B7534740ACC48C6F96B33184 |
| config/universe/geo_project.yaml | config/universe/geo_project.yaml | D69A31F702B3AEC8D886799A6F765580CFCE83AB40FB719178C5880BAB25D6E6 |
| config/universe/positioning.yaml | config/universe/positioning.yaml | DA38E7B02B1AF762A4375E936922E2D44180F2C6C91A81FD05A9F9ED4D4195A2 |
| config/universe/realm_governance.yaml | config/universe/realm_governance.yaml | 22198BD767C31818B66B41EFF6A3DD8E51EA49D11FE3C5AC919A969FD5EF6D4F |
| backend/app/services/project_plan_service.py | backend/app/services/project_plan_service.py | EC6F58B5FAC529A9F31C3462C30F9FA93286AB1B7CA0B5A12303CD58387191B7 |
| backend/app/api/v1/project_plans.py | backend/app/api/v1/project_plans.py | 82C139AB56867EDB51A9573CE65C0CC9CA211CB252E29809FCA9CC0299E21A58 |
| backend/app/main.py | backend/app/main.py | 06FF45C55B9ED2CA871FF0430A962A253084269DB484A596F9D6E4AD5E1A948E |
| backend/app/services/geo_project_service.py | backend/app/services/geo_project_service.py | 6CCF5D1E8978F710F9C05DD7D1962F49873A691AAFDD2A9ABA22F6CE776B55C6 |
| backend/app/services/intake_service.py | backend/app/services/intake_service.py | B1884FD8B018599E2D9CD5B0564BF02919A05ED29F0F5AB612DC2E28DC335DB0 |
| backend/app/services/governance.py | backend/app/services/governance.py | 5362D741B2B8CC42912B3A2B0001CE6E77769888021E15BCF9C16CC4DD1467FC |
| backend/app/api/v1/intakes.py | backend/app/api/v1/intakes.py | 5AED2E7FD459639CFC2E76F7934892E89B85A0C8773E78833391547BAC74DAC5 |
| backend/tests/test_v10p6_r3_project_plan.py | backend/tests/test_v10p6_r3_project_plan.py | 5175BB0D784B827208CFDCCAF4272314C4C84B6898D70821CAAFD7443D8D9DF2 |
| backend/tests/test_v10p6_r2_client_positioning.py | backend/tests/test_v10p6_r2_client_positioning.py | 812C9A1D9EA40BC918387B0CC98F16035D33A8A67201AE9BD9AF51495558A2A1 |
| backend/tests/test_v10p6_r1_public_intake.py | backend/tests/test_v10p6_r1_public_intake.py | 4F425351932CFDBAE208C5B58BB44A197F3B96FCB5F33EF183F36EC1621F293C |
| frontend/src/components/realm-owner/project-plan-workbench.tsx | frontend/src/components/realm-owner/project-plan-workbench.tsx | 8D1E6745B6A67665A0C4E246B1B16E5F7E51A05584A3F2B42E913369460F1052 |
| frontend/src/lib/realm-owner/r3-project-plan.ts | frontend/src/lib/realm-owner/r3-project-plan.ts | 03C6EA7A41B890EDC32E3A4AFC26BE4B8CB2B543B6302C316BDC03C57E1C67BC |
| frontend/src/components/realm-owner/realm-owner-section-page.tsx | frontend/src/components/realm-owner/realm-owner-section-page.tsx | 43B9114F744DE4CD48F23FCEA12481BAE461356F7AC9F3CDB3EB3121DA51DCD0 |
| frontend/src/components/app-shell/surface-config.ts | frontend/src/components/app-shell/surface-config.ts | 54B97805508398ABFA5877C19F26F4B2DEEB8985391AA4C757A3D32570837C72 |
| frontend/src/app/realm/[realm_id]/projects/page.tsx | frontend/src/app/realm/[realm_id]/projects/page.tsx | 3EB9641E4481F8F3ABAF488855EDA317D93E04655E4F2A9130BD1AFE2E300743 |
| frontend/scripts/check-v106-preview.mjs | frontend/scripts/check-v106-preview.mjs | FA3B8440DBB42741329EBC94A6D48BF73A17A9C5273BB1BAE502CB932B395F45 |
| frontend/scripts/capture-v106-r3-screenshots.mjs | frontend/scripts/capture-v106-r3-screenshots.mjs | 7238BC24552D6BB8974DD6D4B09372A50A4FFDBD9B16B6B2B2AE832A92F74B4D |
| frontend/scripts/capture-v106-r21-preview-states.mjs | frontend/scripts/capture-v106-r21-preview-states.mjs | 26C8067DCF10FF8F9B05F61F12B6753783B765A1DFBF22972BFB4D2A977C2D40 |
| scripts/verify_v106_r3_package.py | scripts/verify_v106_r3_package.py | D6F8B0AF1B2CF0F926D8A14171BFB5322D1367F32DD2ED0C8A1557440F5B0FB5 |
| frontend/tests/operations/operations-adapter.test.ts | frontend/tests/operations/operations-adapter.test.ts | 8B3728B43801F19CB5A3F4A2592FD86B865DDCF0FA87D320F5F042F2297DDC0F |
| frontend/tests/public-intake/form.test.ts | frontend/tests/public-intake/form.test.ts | EEF1B608239BF1A9DACDAFAE6A34B9BAB1246F8972ED42F3590C7D5C608E21EC |
| frontend/tests/realm-owner-home/adapter.test.ts | frontend/tests/realm-owner-home/adapter.test.ts | 4E3B9DEBFF5469FC033551E6078BD1FEFC964E7F8DD7C41C4205749C422E8677 |
| frontend/tests/realm-owner-home/ts-loader.mjs | frontend/tests/realm-owner-home/ts-loader.mjs | 25425BCB900182079E6C503BD17368826698A1A8A7C7DF89927DA131D97A2110 |
| docs/generated_images/V10.6-R3-01-projects-empty.png | docs/generated_images/V10.6-R3-01-projects-empty.png | 2AA1DEBFEDC2C6792AFE48BD58C8C7CE25E6385659B4EDEF4B62A5348F1E72DF |
| docs/generated_images/V10.6-R3-02-r2-project-enter.png | docs/generated_images/V10.6-R3-02-r2-project-enter.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-03-workflow-source.png | docs/generated_images/V10.6-R3-03-workflow-source.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-04-plan-draft.png | docs/generated_images/V10.6-R3-04-plan-draft.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-05-unknown-partial.png | docs/generated_images/V10.6-R3-05-unknown-partial.png | 2BC18CD73E8CCFC1F425C42346F281A96E9D8737A51B48043E22A752C2C52443 |
| docs/generated_images/V10.6-R3-06-owner-edit.png | docs/generated_images/V10.6-R3-06-owner-edit.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-07-dependency-date.png | docs/generated_images/V10.6-R3-07-dependency-date.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-08-version-conflict.png | docs/generated_images/V10.6-R3-08-version-conflict.png | 2BC18CD73E8CCFC1F425C42346F281A96E9D8737A51B48043E22A752C2C52443 |
| docs/generated_images/V10.6-R3-09-plan-confirm.png | docs/generated_images/V10.6-R3-09-plan-confirm.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-10-schedule-generated.png | docs/generated_images/V10.6-R3-10-schedule-generated.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-11-task-progress.png | docs/generated_images/V10.6-R3-11-task-progress.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-12-overdue-reminder.png | docs/generated_images/V10.6-R3-12-overdue-reminder.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-13-csv-export.png | docs/generated_images/V10.6-R3-13-csv-export.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-14-no-permission.png | docs/generated_images/V10.6-R3-14-no-permission.png | 4658D0FB3F97DD81130CB624EE33BCC6CF82D2A8E351C46608B00301FEABEE1A |
| docs/generated_images/V10.6-R3-15-narrow-responsive.png | docs/generated_images/V10.6-R3-15-narrow-responsive.png | 4DA97055820839294E57F7DA31494B95AF89CB5EB31A093AF373B52B9D22921C |
| docs/generated_images/V10.6-R3-mock-state-blocked.png | docs/generated_images/V10.6-R3-mock-state-blocked.png | 8B619F249F4A772FBBF226CCD00A434EF52E9B2226DFEF0009890E7B187CACEF |
| docs/generated_images/V10.6-R3-mock-state-empty.png | docs/generated_images/V10.6-R3-mock-state-empty.png | 2AA1DEBFEDC2C6792AFE48BD58C8C7CE25E6385659B4EDEF4B62A5348F1E72DF |
| docs/generated_images/V10.6-R3-mock-state-error.png | docs/generated_images/V10.6-R3-mock-state-error.png | 5108C974AE22EBA10C92D9FB88F857C7EFDA667DF05DA189C512DFF419F46B76 |
| docs/generated_images/V10.6-R3-mock-state-loading.png | docs/generated_images/V10.6-R3-mock-state-loading.png | CCAE233F0DA8B807FF47867BDD476224E306128E5A13BEFAFA14F709DBD842AF |
| docs/generated_images/V10.6-R3-mock-state-no-permission.png | docs/generated_images/V10.6-R3-mock-state-no-permission.png | 4658D0FB3F97DD81130CB624EE33BCC6CF82D2A8E351C46608B00301FEABEE1A |
| docs/generated_images/V10.6-R3-mock-state-normal.png | docs/generated_images/V10.6-R3-mock-state-normal.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-mock-state-partial.png | docs/generated_images/V10.6-R3-mock-state-partial.png | 2BC18CD73E8CCFC1F425C42346F281A96E9D8737A51B48043E22A752C2C52443 |

## 测试结果摘要

- 后端全量：306 passed。
- R3 专项：6 passed。
- 前端测试：18 passed。
- TypeScript：通过。
- lint：通过，仅仓库原有 4 项 warning。
- production build：通过，54 个路由。
- 预览检查：PASS pages=36 meta=36 customerStates=7 projectStates=7 narrow=ok。
- 交付包自检：PASS。

## 未完成项

- 域主自定义模板管理页未建设，接口已预留 owner_defined 来源。
- 已确认计划的 R4 变更控制未实现。
- 生产环境 Redis 未运行，真实限流原子窗口待 Redis 环境验证。

## 已知风险

- platform_seed 仅作草稿，不是行业标准。
- 提醒只做本地记录，不发送外部消息。
- 设计预览为脱机 Mock，不代表真实接口可用性。

## 敏感信息检查结果

- 未包含 `.env`。
- 未包含 Token、API Key、客户隐私或数据库转储。
- 截图来自脱机 Mock 与本地测试环境。
