# V10.6-R2.1-FIX2 最终收口交付 MANIFEST

- 任务编号：V10.6-R2.1-FIX2-FINAL-FREEZE
- 基于版本：V10.6-R2.1-FIX1（R2 已冻结）
- 是否允许部署：否
- 是否允许提交或推送：否
- 交付包：V10.6-R2.1-FIX2-最终收口-执行文件.zip

## 文件清单（ZIP 路径 / 仓库源路径 / SHA-256）

`MANIFEST.md` 为本清单文件，不计算自身哈希；其余文件逐项登记 SHA-256，ZIP 内路径全部为 ASCII。

| ZIP路径（ASCII） | 仓库源路径 | SHA-256 |
| --- | --- | --- |
| docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | ECFB32AE6FDC63C703DE2B123F5189F29DAB9CAB48230B3F83E9048147BE34A8 |
| docs/17-6_V10.6-R2.1-FIX1-acceptance-correction-report.md | docs/17-6_V10.6-R2.1-FIX1验收修正执行报告.md | 9195D3DEE54F605340138890962A93A3EE32553B718D50E18250B070F97D3558 |
| docs/17-5_V10.6-R2.1-UI-delivery-closeout-report.md | docs/17-5_V10.6-R2.1UI同步与交付收口执行报告.md | 5F17C384B0EA7FD9A7DE373326D35E7E0A20139F059294EFBE8D1092C0EB1D0C |
| docs/17-4_V10.6-R2-client-positioning-report.md | docs/17-4_V10.6-R2客户与定位执行报告.md | 03D6D1AF5E2C25DD3AB7E863A9C405D5606907004E46EA67AE6A2C59A2741461 |
| docs/v106-all-pages-design-preview.html | docs/v106-all-pages-design-preview.html | 2BF499BDC96899DB1597398FE5B57BA6E843844B5DEF63FB44C0D527BC99DAFD |
| docs/V10.6-UI-SYNC-PROTOCOL.md | docs/V10.6-UI-SYNC-PROTOCOL.md | F4CF4D1471902F131DEED0F6D9F6AC86E6BC0C5B7B810D8D04DF59373A7EFA84 |
| docs/V10.6-R2.1-code-change-list.md | docs/V10.6-R2.1-代码变更清单.md | EE1D81B1821805DD86B40C0EA9F1E124776899283EC919CE54E00F8D8C087635 |
| docs/18-3-page-integration-list.md | docs/18-3_页面整合清单.md | FB29908D3C7CB9385881F6E0F6D1248D85B4B83EB66DD3495F35FF77F20AF93E |
| scripts/verify_v106_r21_fix2_package.py | scripts/verify_v106_r21_fix2_package.py | D0F423F6C952D285BFD548E5A6853FC381FD605DEA06825EA53E0B9ACE279D81 |
| frontend/scripts/check-v106-preview.mjs | frontend/scripts/check-v106-preview.mjs | D2885A103F05410CDBAF0A2FA6FE532987CF77EEA949BB60DAC77A80CF9F8B7A |
| frontend/scripts/capture-v106-r21-preview-states.mjs | frontend/scripts/capture-v106-r21-preview-states.mjs | 26C8067DCF10FF8F9B05F61F12B6753783B765A1DFBF22972BFB4D2A977C2D40 |
| frontend/scripts/capture-v106-r2-screenshots.mjs | frontend/scripts/capture-v106-r2-screenshots.mjs | 96FEDEA512EB2CDAADAF2765379EED93CCD2444A9F89D5406EB7883B70EC38E9 |
| frontend/scripts/capture-v106-screenshots.mjs | frontend/scripts/capture-v106-screenshots.mjs | 83B8054CAEAF301C657F4F9F70C87A0AF67BD3C9B5DA2015E0EE712669322AE9 |
| frontend/scripts/verify-v106-pages.mjs | frontend/scripts/verify-v106-pages.mjs | 8E01EB09CA40F09BCF700303CD1EA965647C1D9F4A90AAED4E200664FAB12A20 |
| backend/tests/test_v10p6_r2_client_positioning.py | backend/tests/test_v10p6_r2_client_positioning.py | 812C9A1D9EA40BC918387B0CC98F16035D33A8A67201AE9BD9AF51495558A2A1 |
| backend/tests/test_v10p6_r1_public_intake.py | backend/tests/test_v10p6_r1_public_intake.py | 4F425351932CFDBAE208C5B58BB44A197F3B96FCB5F33EF183F36EC1621F293C |
| backend/app/services/intake_service.py | backend/app/services/intake_service.py | B1884FD8B018599E2D9CD5B0564BF02919A05ED29F0F5AB612DC2E28DC335DB0 |
| backend/app/services/geo_project_service.py | backend/app/services/geo_project_service.py | 6CCF5D1E8978F710F9C05DD7D1962F49873A691AAFDD2A9ABA22F6CE776B55C6 |
| backend/app/services/positioning_service.py | backend/app/services/positioning_service.py | 4D9BF9C2F22ECFD6C381F7EDB6C0E200FBF6C47BCEA2927E6CF5605C655DA24E |
| backend/app/services/realm_service.py | backend/app/services/realm_service.py | 2CF7A31C075D2FF63A483C949C56C1BB5EF8EBC62D94293A9E864F9CA13FD6DA |
| backend/app/services/intake_rate_limiter.py | backend/app/services/intake_rate_limiter.py | C9CB38F874E4743B3E99B95F670AA2CAB06964AEF706DC8AEDFF2FD6B01413C3 |
| backend/app/services/governance.py | backend/app/services/governance.py | 5362D741B2B8CC42912B3A2B0001CE6E77769888021E15BCF9C16CC4DD1467FC |
| backend/app/api/v1/intakes.py | backend/app/api/v1/intakes.py | 5AED2E7FD459639CFC2E76F7934892E89B85A0C8773E78833391547BAC74DAC5 |
| backend/app/models/intake.py | backend/app/models/intake.py | 1DC9BD4EE1DBC8ED265B21E46DFC6F3BF91D37CAF39EF0C5562F4B92E0EEA62C |
| backend/app/models/geo_project.py | backend/app/models/geo_project.py | 4558B9F09AE1C84D1F8BC014653C2B5A6C81241E37E0322B0911A4C13585975D |
| backend/app/models/realm.py | backend/app/models/realm.py | FF4B7C4E44634D8F2C9122418E99B6EF415EC13123A46C042B916DA921F1AA6E |
| config/universe/positioning.yaml | config/universe/positioning.yaml | DA38E7B02B1AF762A4375E936922E2D44180F2C6C91A81FD05A9F9ED4D4195A2 |
| config/universe/realm_governance.yaml | config/universe/realm_governance.yaml | 22198BD767C31818B66B41EFF6A3DD8E51EA49D11FE3C5AC919A969FD5EF6D4F |
| frontend/src/components/app-shell/AppShell.tsx | frontend/src/components/app-shell/AppShell.tsx | 3C82269AE04A6A8B6FAE9F2CB9BF351CA99F33346A75671019024AB94BD388A3 |
| frontend/src/components/app-shell/surface-config.ts | frontend/src/components/app-shell/surface-config.ts | DC3E5BA8C5D245C2EE710EB925A51731CDE4D265E356584FFB467228B647D954 |
| frontend/src/components/app-shell/ApprovalItem.tsx | frontend/src/components/app-shell/ApprovalItem.tsx | 1C23E85E4DBEB726847F832D4EFEB2014F3731134765B0876A934B5EC8CD2348 |
| frontend/src/components/app-shell/DataSourceBadge.tsx | frontend/src/components/app-shell/DataSourceBadge.tsx | 3E612E80E58BFDDD3A381D28F69DA30CFBAC5093019695F47477A11DF568E8A5 |
| frontend/src/components/app-shell/StatusStrip.tsx | frontend/src/components/app-shell/StatusStrip.tsx | 2C67F97146CBF7D96A2767AB7305E94047151B741A67ABF60135DFE2BA190035 |
| frontend/src/components/realm-owner/realm-owner-shell.tsx | frontend/src/components/realm-owner/realm-owner-shell.tsx | 738608F069079DE62E1DBB72B1F94FB5E851E24230A2214BB66BB13E30B3A60F |
| frontend/src/components/realm-owner/client-positioning-workbench.tsx | frontend/src/components/realm-owner/client-positioning-workbench.tsx | 9DB4E40B50369A77F78F4C537465ADF14E572C7B15E00077C61FAC0E5A161FD8 |
| frontend/src/components/realm-owner/realm-owner-section-page.tsx | frontend/src/components/realm-owner/realm-owner-section-page.tsx | 0D5C009C877CB3BD71A83643A41E5B160F712BABC6F493047995D085C2C42B3A |
| frontend/src/components/realm-owner/detail-drawers.tsx | frontend/src/components/realm-owner/detail-drawers.tsx | E0BC6DF3743437BFEF843BDD6583EA7FB490F33BD2A52B8F4918444ADAB6C018 |
| frontend/src/components/realm-owner/drawer.tsx | frontend/src/components/realm-owner/drawer.tsx | 772378F1B8EFD0A4B091CFEDBE7092DED77466241D4A9218EEFD72AAC9836485 |
| frontend/src/components/realm-owner/module-state.tsx | frontend/src/components/realm-owner/module-state.tsx | 57B529AFE47B8C98A40B4A0C97A59FFE00571BB0635756CF78A2D5E788ED7EB2 |
| frontend/src/components/realm-owner/truth-badge.tsx | frontend/src/components/realm-owner/truth-badge.tsx | B3153DDE6865CFF7A8D6D222ABA5386EF96EB977316C5BDF09C439C81878391E |
| frontend/src/components/public-intake/public-intake-page.tsx | frontend/src/components/public-intake/public-intake-page.tsx | E8F688B2CB0458AFC565867197C67108391B5202F64160E9D6ADA80E98F1216C |
| frontend/src/app/v106-all-pages-design-preview/route.ts | frontend/src/app/v106-all-pages-design-preview/route.ts | 3D2B9923A75F32604F766F14F8470D2CEE5D8D35992F01825FDEEE07983A072F |
| frontend/src/app/realm/[realm_id]/customers/page.tsx | frontend/src/app/realm/[realm_id]/customers/page.tsx | 2234FF486D21943F8EAC8A5EAC4E63107AFBE5BA5D17EB3EBC8DB13D26212913 |
| frontend/src/app/realm/[realm_id]/explore/page.tsx | frontend/src/app/realm/[realm_id]/explore/page.tsx | 0B143261D19CA9F69377B8FE645D085C883C79B457897692CF446DE7CD2647BC |
| frontend/src/lib/realm-owner/r2-client-positioning.ts | frontend/src/lib/realm-owner/r2-client-positioning.ts | 98C0E2F21C80C8A99E29B21BBCE8788825E516E9764057EF89A43C94DD6C95EF |
| frontend/src/lib/realm-owner/adapter.ts | frontend/src/lib/realm-owner/adapter.ts | 771A567D3A75DB56599FB18B818E3AC5C2591574B569934C08C35933BF64AA18 |
| frontend/src/lib/public-intake/form.ts | frontend/src/lib/public-intake/form.ts | 829654EFB8D9BEDBF0AFD944393B913AE87E0D92809A3F97C5EF181CEBD68258 |
| frontend/src/lib/public-intake/api.ts | frontend/src/lib/public-intake/api.ts | 21CD5150847EBB9F1CC95F187ABF454D4679B91372914C91D2F45903A713CE6D |
| frontend/src/lib/public-intake/types.ts | frontend/src/lib/public-intake/types.ts | A1132593A87F801DB847C364F12B0F815AC95124C0D7391D2D8C2AB63F796B48 |
| frontend/next.config.js | frontend/next.config.js | E3D0EC5F335EFD17BE545A47C4DE8F2DC4EDF8E3F65D1D26068FDF97501EC250 |
| frontend/public/v106-all-links.html | frontend/public/v106-all-links.html | F6E8CCCE998F718D563C72ABC79B2D8B684C6BC968762BAC92DFE82E4572EA5F |
| frontend/tests/operations/operations-adapter.test.ts | frontend/tests/operations/operations-adapter.test.ts | 8B3728B43801F19CB5A3F4A2592FD86B865DDCF0FA87D320F5F042F2297DDC0F |
| frontend/tests/public-intake/form.test.ts | frontend/tests/public-intake/form.test.ts | EEF1B608239BF1A9DACDAFAE6A34B9BAB1246F8972ED42F3590C7D5C608E21EC |
| frontend/tests/realm-owner-home/adapter.test.ts | frontend/tests/realm-owner-home/adapter.test.ts | 4E3B9DEBFF5469FC033551E6078BD1FEFC964E7F8DD7C41C4205749C422E8677 |
| frontend/tests/realm-owner-home/ts-loader.mjs | frontend/tests/realm-owner-home/ts-loader.mjs | 25425BCB900182079E6C503BD17368826698A1A8A7C7DF89927DA131D97A2110 |
| docs/generated_images/V10.6-R2-01-customers-empty.png | docs/generated_images/V10.6-R2-01-customers-empty.png | 75057C0F1B2AF4E445C01AA5F4F2B71C133E95051C152A8DC8FD7EAE1AD97489 |
| docs/generated_images/V10.6-R2-02-customers-awaiting.png | docs/generated_images/V10.6-R2-02-customers-awaiting.png | 43FCFE953F36DD4C9549BC6BAE512253861F74D48AD91AF5C5B6504AAA22B4E1 |
| docs/generated_images/V10.6-R2-03-profile-partial-unknown.png | docs/generated_images/V10.6-R2-03-profile-partial-unknown.png | 896C0863F98E8889536A37B5BACDE00005B8F1A7BDE1D5236C2A3D8FB1F54448 |
| docs/generated_images/V10.6-R2-04-mock-state-partial.png | docs/generated_images/V10.6-R2-04-mock-state-partial.png | 7B50B6364F15A89C016411D1BA1B297AF09107B5AF10BA87472F359DE5AAA24A |
| docs/generated_images/V10.6-R2-05-owner-edit.png | docs/generated_images/V10.6-R2-05-owner-edit.png | 41D9778BE6D6FE416D56B35DAD83604E73A4A2C9922D5FF7BE4131D5A044EF15 |
| docs/generated_images/V10.6-R2-06-profile-confirmed.png | docs/generated_images/V10.6-R2-06-profile-confirmed.png | 50088A80BBA51F605E2EBB98A2085D8BF7DC6F48B6FAA1974B35076BEC30A8B3 |
| docs/generated_images/V10.6-R2-07-positioning-draft.png | docs/generated_images/V10.6-R2-07-positioning-draft.png | 688EEEC8C954737104EAA8FE644C95110263470A096F9AD89F2B95DBA29006B8 |
| docs/generated_images/V10.6-R2-08-positioning-confirmed.png | docs/generated_images/V10.6-R2-08-positioning-confirmed.png | 51FD29FB4FA0566556134B3E374F7B8F13A3A0FC007A440ECB9041BCF9195AA3 |
| docs/generated_images/V10.6-R2-09-project-trigger-confirm.png | docs/generated_images/V10.6-R2-09-project-trigger-confirm.png | 2D8B7A06BA38670B31FA4C2170B2DB57F8834E6B7C362919EFEC0D53D92A54E7 |
| docs/generated_images/V10.6-R2-10-project-created.png | docs/generated_images/V10.6-R2-10-project-created.png | 1BC45C1187963EC62D45D3593245FB161D5543DAA9203AB98431622A70AD7D0F |
| docs/generated_images/V10.6-R2-11-no-permission.png | docs/generated_images/V10.6-R2-11-no-permission.png | 1EF5C2B7D654B0C8700D24AD32BC754434047C0B41311F7EE3E4CE97F7BAD2F3 |
| docs/generated_images/V10.6-R2-12-narrow-responsive.png | docs/generated_images/V10.6-R2-12-narrow-responsive.png | 6CBB5A7BD238811ECC32E6503D6ED1042B2630A6BA4BDCE2CCE1A54F21129E8B |
| docs/generated_images/V10.6-R2.1-mock-state-blocked.png | docs/generated_images/V10.6-R2.1-mock-state-blocked.png | D6A01D7E749BF1092A32C9F97DB73C455F5E1F44CF12B094466934C4B7A879F2 |
| docs/generated_images/V10.6-R2.1-mock-state-empty.png | docs/generated_images/V10.6-R2.1-mock-state-empty.png | 10AFA32BAF3535BAABDBBFB206F22B23E0467F12F4EFD348EEE1C9C1F39E5FA1 |
| docs/generated_images/V10.6-R2.1-mock-state-error.png | docs/generated_images/V10.6-R2.1-mock-state-error.png | 303DB5199554495A4E641AFB947CDBA98C0C9A8DC644D3C1054A81D8FAA2740D |
| docs/generated_images/V10.6-R2.1-mock-state-loading.png | docs/generated_images/V10.6-R2.1-mock-state-loading.png | 8B4B46B4548D1B3FECA4BE7252515171E4F4C78A958BBB542584DF50EFD0E177 |
| docs/generated_images/V10.6-R2.1-mock-state-no-permission.png | docs/generated_images/V10.6-R2.1-mock-state-no-permission.png | 770320786F0AC9F918F62BC2A4571B0A8D1F492F77500996EE2DC149384A70BC |
| docs/generated_images/V10.6-R2.1-mock-state-normal.png | docs/generated_images/V10.6-R2.1-mock-state-normal.png | 29555F8D2D83605D72DA480818546E65E1C85851A8A0DBBA3581E192694ACA20 |
| docs/generated_images/V10.6-R2.1-mock-state-partial.png | docs/generated_images/V10.6-R2.1-mock-state-partial.png | 7B50B6364F15A89C016411D1BA1B297AF09107B5AF10BA87472F359DE5AAA24A |

## 本轮变更文件

- docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md
- docs/17-6_V10.6-R2.1-FIX1验收修正执行报告.md
- docs/v106-all-pages-design-preview.html
- docs/V10.6-R2.1-代码变更清单.md
- scripts/verify_v106_r21_fix2_package.py
- backend/tests/test_v10p6_r2_client_positioning.py
- backend/app/services/intake_service.py
- backend/app/services/geo_project_service.py
- backend/app/services/governance.py
- docs/generated_images/V10.6-R2.1-mock-state-blocked.png
- docs/generated_images/V10.6-R2.1-mock-state-empty.png
- docs/generated_images/V10.6-R2.1-mock-state-error.png
- docs/generated_images/V10.6-R2.1-mock-state-loading.png
- docs/generated_images/V10.6-R2.1-mock-state-no-permission.png
- docs/generated_images/V10.6-R2.1-mock-state-normal.png
- docs/generated_images/V10.6-R2.1-mock-state-partial.png

## 测试结果摘要

- 后端全量：300 passed。
- R2 定位专项：7 passed。
- 前端测试：18 passed。
- TypeScript：通过。
- lint：通过，仅仓库原有 4 项 warning。
- production build：通过，54 个路由。
- 设计预览检查：PASS pages=36 meta=36 customerStates=7 narrow=ok errors=0。
- 交付包自检：PASS。

## 未完成项

- 生产环境 Redis 未运行，真实限流原子窗口待 Redis 环境验证。
- 公网部署前仍需处理 Origin/CSRF、Referrer Policy、访问日志 Token 脱敏与资料保留策略。

## 已知风险

- Windows 上 asyncpg 同一事件循环并发行锁等待存在客户端协议卡顿；并发测试使用独立线程与独立 engine 验证 DB 锁语义。
- 设计预览为脱机 Mock，不代表真实接口可用性。
- 本地实施版本冻结不表示可直接公网部署。

## 敏感信息检查结果

- 未包含 `.env`。
- 未包含 Token、API Key、客户隐私或数据库转储。
- 截图来自脱机 Mock 与本地测试环境，已确认不含完整 Token 或乱码测试数据。
