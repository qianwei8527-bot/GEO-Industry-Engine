export type ApplicationSurface = "owner" | "public" | "operations" | "governance";

export interface SurfaceProtocol {
  label: string;
  protocolStatus: "implemented" | "reserved";
  navItems: Array<{
    id: string;
    label: string;
    iconKey: string;
    status: "open" | "planned" | "disabled";
  }>;
}

export const APPLICATION_SURFACES: Record<ApplicationSurface, SurfaceProtocol> = {
  owner: {
    label: "域主工作台",
    protocolStatus: "implemented",
    navItems: [
      { id: "today", label: "今日工作", iconKey: "inbox", status: "planned" },
      { id: "customers", label: "客户与定位", iconKey: "users", status: "open" },
      { id: "projects", label: "项目与计划", iconKey: "package", status: "planned" },
      { id: "execution", label: "执行与问题", iconKey: "play", status: "planned" },
      { id: "results", label: "结果与资产", iconKey: "database", status: "planned" },
      { id: "tools", label: "工具与连接", iconKey: "link", status: "planned" },
    ],
  },
  public: {
    label: "公共世界与客户协作端",
    protocolStatus: "implemented",
    navItems: [{ id: "intake", label: "资料提交", iconKey: "filePlus", status: "open" }],
  },
  operations: {
    label: "平台运营后台",
    protocolStatus: "implemented",
    navItems: [
      { id: "overview", label: "平台总览", iconKey: "layoutDashboard", status: "open" },
      { id: "runtime", label: "运行任务", iconKey: "activity", status: "open" },
      { id: "connectors", label: "工具与连接", iconKey: "plugZap", status: "open" },
      { id: "capabilities", label: "Agent 与能力", iconKey: "bot", status: "open" },
      { id: "workflows", label: "工作流", iconKey: "workflow", status: "open" },
      { id: "reports", label: "报告与结果", iconKey: "fileText", status: "open" },
      { id: "system", label: "系统与配置", iconKey: "settings", status: "open" },
    ],
  },
  governance: {
    label: "治理审计台",
    protocolStatus: "implemented",
    navItems: [
      { id: "permissions", label: "权限策略", iconKey: "users", status: "open" },
      { id: "approvals", label: "审批中心", iconKey: "shieldCheck", status: "open" },
      { id: "audit", label: "审计日志", iconKey: "fileText", status: "open" },
      { id: "risk", label: "风险控制", iconKey: "lock", status: "open" },
      { id: "collective", label: "共同治理", iconKey: "gitBranch", status: "planned" },
    ],
  },
};
