import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || "playwright");
if (!process.env.CHROME_PATH || !process.env.PLAYWRIGHT_PATH) {
  throw new Error("set CHROME_PATH and PLAYWRIGHT_PATH");
}
import { existsSync, mkdirSync } from "node:fs";
import path from "node:path";

const base = process.env.V106_R4_REAL_BASE || "http://localhost:3109";
const realm = process.env.V106_R4_REAL_REALM;
const token = process.env.V106_R4_REAL_TOKEN;
const outsiderToken = process.env.V106_R4_REAL_OUTSIDER_TOKEN;
if (!realm || !token || !outsiderToken) {
  throw new Error("set V106_R4_REAL_REALM, V106_R4_REAL_TOKEN and V106_R4_REAL_OUTSIDER_TOKEN");
}
const outDir = path.resolve("..", "docs", "generated_images");
if (!existsSync(outDir)) mkdirSync(outDir, { recursive: true });

const browser = await chromium.launch({
  executablePath: process.env.CHROME_PATH,
  headless: true,
  args: ["--disable-gpu", "--no-sandbox"],
});

try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  await context.addInitScript(({ value }) => localStorage.setItem("geo_token", value), { value: token });
  const page = await context.newPage();
  const errors = [];
  page.on("console", (message) => { if (message.type() === "error") errors.push(message.text()); });
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(`${base}/realm/${realm}/execution`, { waitUntil: "domcontentloaded" });
  await page.getByText("执行与问题闭环", { exact: false }).first().waitFor({ timeout: 20000 });
  await page.waitForTimeout(1500);
  const firstIssue = page.locator("button", { hasText: "权限校验失败" }).first();
  if (await firstIssue.count()) {
    await firstIssue.click();
    await page.waitForTimeout(600);
  }
  await page.screenshot({ path: path.join(outDir, "V10.6-R4-REAL-01-issue-workbench.png") });
  await page.evaluate(() => {
    const heading = Array.from(document.querySelectorAll("h2, div")).find((element) =>
      element.textContent?.includes("业务 Skill 草稿"),
    );
    heading?.scrollIntoView({ block: "start" });
  });
  await page.waitForTimeout(600);
  await page.screenshot({ path: path.join(outDir, "V10.6-R4-REAL-02-skill-draft.png") });
  console.log(`real owner errors=${errors.length}`);
  await context.close();

  const narrow = await browser.newContext({ viewport: { width: 390, height: 844 } });
  await narrow.addInitScript(({ value }) => localStorage.setItem("geo_token", value), { value: token });
  const narrowPage = await narrow.newPage();
  await narrowPage.goto(`${base}/realm/${realm}/execution`, { waitUntil: "domcontentloaded" });
  await narrowPage.getByText("执行与问题闭环", { exact: false }).first().waitFor({ timeout: 20000 });
  await narrowPage.waitForTimeout(1000);
  const overflow = await narrowPage.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    clientWidth: document.documentElement.clientWidth,
  }));
  if (overflow.scrollWidth > overflow.clientWidth + 1) {
    throw new Error(`narrow overflow: ${overflow.scrollWidth} > ${overflow.clientWidth}`);
  }
  await narrowPage.screenshot({ path: path.join(outDir, "V10.6-R4-REAL-03-narrow-responsive.png"), fullPage: true });
  await narrow.close();

  const denied = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  await denied.addInitScript(({ value }) => localStorage.setItem("geo_token", value), { value: outsiderToken });
  const deniedPage = await denied.newPage();
  await deniedPage.goto(`${base}/realm/${realm}/execution`, { waitUntil: "domcontentloaded" });
  await deniedPage.getByText("无权限", { exact: false }).first().waitFor({ timeout: 20000 });
  await deniedPage.waitForTimeout(800);
  await deniedPage.screenshot({ path: path.join(outDir, "V10.6-R4-REAL-04-no-permission.png") });
  await denied.close();
  console.log("saved r4 real screenshots");
} finally {
  await browser.close();
}
