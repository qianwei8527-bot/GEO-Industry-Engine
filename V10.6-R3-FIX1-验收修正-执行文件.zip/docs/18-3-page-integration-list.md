# 恒域世界 页面整合清单

## 1. 页面统计

整合前页面路由：56 个
整合后页面路由：54 个

## 2. 保留主应用页面

### 域主工作台

- /realm/{id}/explore
- /realm/{id}/customers
- /realm/{id}/projects
- /realm/{id}/execution
- /realm/{id}/results
- /realm/{id}/tools

### 公共世界与客户协作端

- /public
- /intake/{secure_token}
- /client
- /market

### 平台运营后台

- /operations

### 治理审计台

- /governance

### 中台与后端

- /midplatform
- /backend

### 基础入口

- /
- /login
- /register
- /realm（域主看板）
- /system-map

## 3. 已整合页面

| 原页面 | 处理 | 目标 |
| --- | --- | --- |
| /universe/navigation | 删除重复入口 | /navigation |
| /universe | 重定向 | /navigation |
| /realm/capabilities | 删除并整合 | /realm（域主看板） |

## 4. 旧版工具页面

以下页面暂时保留，不再出现在一级导航，作为旧版兼容入口：

- /detection、/detection/compare、/detection/result
- /intelligence、/intelligence/{id}、/intelligence/competitors、/intelligence/opportunities、/intelligence/risks
- /marketplace、/marketplace/demand/{id}、/marketplace/provider/{id}
- /certification、/certification/apply、/certification/passport/{id}、/certification/review-status
- /identity
- /assets
- /company/{id}
- /navigation
- /universe/3d、/universe/connections、/universe/growth、/universe/home、/universe/home/{node}、/universe/join、/universe/opportunities、/universe/trust

## 5. 旧版管理后台

- /admin 及其子页面暂时保留，后续统一并入 /operations 与 /governance。

## 6. 设计预览静态页面

- /v106-design-index.html
- /v106-design-frontend.html
- /v106-design-backoffice.html
- /v106-design-midplatform.html
- /v106-design-backend.html
- docs/v106-all-pages-design-preview.html（唯一真相源；Web 地址 /v106-all-pages-design-preview.html 由 Next 路由只读返回）
- /v106-all-links.html
