# V10.6-R3-FIX1 验收修正交付 MANIFEST

- 任务编号：V10.6-R3-FIX1-ACCEPTANCE-CORRECTION
- 前置状态：V10.6-R3 已实施
- 是否允许部署：否
- 是否允许提交或推送：否
- 交付包：V10.6-R3-FIX1-验收修正-执行文件.zip

## 文件清单（ZIP 路径 / 仓库源路径 / SHA-256）

`MANIFEST.md` 为本清单文件，不计算自身哈希；ZIP 内路径全部为 ASCII。

| ZIP路径（ASCII） | 仓库源路径 | SHA-256 |
| --- | --- | --- |
| docs/17-9_V10.6-R3-FIX1-acceptance-correction-report.md | docs/17-9_V10.6-R3-FIX1-acceptance-correction-report.md | 9D22B90427249E64695EEA4C0845DE922A82CD6C3F40E80E7F5922ADFAA7C9FA |
| docs/V10.6-R3-code-change-list.md | docs/V10.6-R3-code-change-list.md | 5EBAECAC9E22BE5F0CBBD6B02E12E4D83951E836F7500C96F7CADA5FC6E4BAE9 |
| docs/17-8_V10.6-R3-project-plan-execution-report.md | docs/17-8_V10.6-R3-project-plan-execution-report.md | 6BC151AE93971A1DE595AD92BAEE29D1A5BD8B7C2103828BCD972C7B34B6198B |
| docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | docs/17-7_V10.6-R2.1-FIX2-final-freeze-report.md | ECFB32AE6FDC63C703DE2B123F5189F29DAB9CAB48230B3F83E9048147BE34A8 |
| docs/17-6_V10.6-R2.1-FIX1-acceptance-correction-report.md | docs/17-6_V10.6-R2.1-FIX1验收修正执行报告.md | 9195D3DEE54F605340138890962A93A3EE32553B718D50E18250B070F97D3558 |
| docs/17-5_V10.6-R2.1-UI-delivery-closeout-report.md | docs/17-5_V10.6-R2.1UI同步与交付收口执行报告.md | 5F17C384B0EA7FD9A7DE373326D35E7E0A20139F059294EFBE8D1092C0EB1D0C |
| docs/17-4_V10.6-R2-client-positioning-report.md | docs/17-4_V10.6-R2客户与定位执行报告.md | 03D6D1AF5E2C25DD3AB7E863A9C405D5606907004E46EA67AE6A2C59A2741461 |
| docs/v106-all-pages-design-preview.html | docs/v106-all-pages-design-preview.html | D57D366449D14B5410E841BED2BDCA86103983F416C9FF8369DCE04B65C3CD63 |
| docs/V10.6-UI-SYNC-PROTOCOL.md | docs/V10.6-UI-SYNC-PROTOCOL.md | F4CF4D1471902F131DEED0F6D9F6AC86E6BC0C5B7B810D8D04DF59373A7EFA84 |
| docs/V10.6-R2.1-code-change-list.md | docs/V10.6-R2.1-代码变更清单.md | EE1D81B1821805DD86B40C0EA9F1E124776899283EC919CE54E00F8D8C087635 |
| docs/18-3-page-integration-list.md | docs/18-3_页面整合清单.md | FB29908D3C7CB9385881F6E0F6D1248D85B4B83EB66DD3495F35FF77F20AF93E |
| config/universe/project_plan.yaml | config/universe/project_plan.yaml | 820F8D0AD27DB242B5E3ECE95E7F4812A499DFA48B9A05E65CC8A08474723318 |
| config/universe/geo_project.yaml | config/universe/geo_project.yaml | D69A31F702B3AEC8D886799A6F765580CFCE83AB40FB719178C5880BAB25D6E6 |
| config/universe/positioning.yaml | config/universe/positioning.yaml | DA38E7B02B1AF762A4375E936922E2D44180F2C6C91A81FD05A9F9ED4D4195A2 |
| config/universe/realm_governance.yaml | config/universe/realm_governance.yaml | 22198BD767C31818B66B41EFF6A3DD8E51EA49D11FE3C5AC919A969FD5EF6D4F |
| backend/app/services/project_plan_service.py | backend/app/services/project_plan_service.py | 2CD400A33DC8BB7B2B6903E06D691B3AE7802A79D6A564FEA4171CA79F9836B5 |
| backend/app/api/v1/project_plans.py | backend/app/api/v1/project_plans.py | 82C139AB56867EDB51A9573CE65C0CC9CA211CB252E29809FCA9CC0299E21A58 |
| backend/app/main.py | backend/app/main.py | 06FF45C55B9ED2CA871FF0430A962A253084269DB484A596F9D6E4AD5E1A948E |
| backend/tests/test_v10p6_r3_project_plan.py | backend/tests/test_v10p6_r3_project_plan.py | 99ADFCDF49BC3E454B189F186958C2280698767383DC12B8B7D42D5D6D728D58 |
| backend/tests/test_v10p6_r2_client_positioning.py | backend/tests/test_v10p6_r2_client_positioning.py | 812C9A1D9EA40BC918387B0CC98F16035D33A8A67201AE9BD9AF51495558A2A1 |
| backend/tests/test_v10p6_r1_public_intake.py | backend/tests/test_v10p6_r1_public_intake.py | 4F425351932CFDBAE208C5B58BB44A197F3B96FCB5F33EF183F36EC1621F293C |
| frontend/src/components/realm-owner/project-plan-workbench.tsx | frontend/src/components/realm-owner/project-plan-workbench.tsx | F64D089137D544CC248B586827E81F76322E58CF9A85712F4156C0DD2ED5E043 |
| frontend/src/lib/realm-owner/r3-project-plan.ts | frontend/src/lib/realm-owner/r3-project-plan.ts | A55D99866799F4CE29A96D98199E74217DFA55051F3CBFCFC7E3123F05B6012E |
| frontend/src/components/realm-owner/realm-owner-section-page.tsx | frontend/src/components/realm-owner/realm-owner-section-page.tsx | BA788C0AC54BF1B0A5A3DDE744FD30807BE741F7C71548C4E632C9AFEE2C4D43 |
| frontend/src/components/app-shell/surface-config.ts | frontend/src/components/app-shell/surface-config.ts | 54B97805508398ABFA5877C19F26F4B2DEEB8985391AA4C757A3D32570837C72 |
| frontend/src/app/realm/[realm_id]/projects/page.tsx | frontend/src/app/realm/[realm_id]/projects/page.tsx | 3EB9641E4481F8F3ABAF488855EDA317D93E04655E4F2A9130BD1AFE2E300743 |
| frontend/next.config.js | frontend/next.config.js | E3D0EC5F335EFD17BE545A47C4DE8F2DC4EDF8E3F65D1D26068FDF97501EC250 |
| frontend/package.json | frontend/package.json | 9F4F6727EC33B2E49837CD167EDA8530FF2E2703F09AEFEED8759B989BC0845B |
| frontend/tests/realm-owner-home/r3-project-plan.test.ts | frontend/tests/realm-owner-home/r3-project-plan.test.ts | E689B2909EDB7196B9827149AD37D236032911161590E957B460CF8D918D01B2 |
| frontend/tests/realm-owner-home/adapter.test.ts | frontend/tests/realm-owner-home/adapter.test.ts | 4E3B9DEBFF5469FC033551E6078BD1FEFC964E7F8DD7C41C4205749C422E8677 |
| frontend/tests/realm-owner-home/ts-loader.mjs | frontend/tests/realm-owner-home/ts-loader.mjs | 25425BCB900182079E6C503BD17368826698A1A8A7C7DF89927DA131D97A2110 |
| frontend/tests/public-intake/form.test.ts | frontend/tests/public-intake/form.test.ts | EEF1B608239BF1A9DACDAFAE6A34B9BAB1246F8972ED42F3590C7D5C608E21EC |
| frontend/tests/operations/operations-adapter.test.ts | frontend/tests/operations/operations-adapter.test.ts | 8B3728B43801F19CB5A3F4A2592FD86B865DDCF0FA87D320F5F042F2297DDC0F |
| frontend/scripts/check-v106-preview.mjs | frontend/scripts/check-v106-preview.mjs | FA3B8440DBB42741329EBC94A6D48BF73A17A9C5273BB1BAE502CB932B395F45 |
| frontend/scripts/capture-v106-r3-screenshots.mjs | frontend/scripts/capture-v106-r3-screenshots.mjs | 7238BC24552D6BB8974DD6D4B09372A50A4FFDBD9B16B6B2B2AE832A92F74B4D |
| frontend/scripts/capture-v106-r3-real-screenshots.mjs | frontend/scripts/capture-v106-r3-real-screenshots.mjs | A0B26F2A813C6E6FEA0E92D1044914430018921783F4F10FE4761BEC0DC2B4CD |
| frontend/scripts/capture-v106-r21-preview-states.mjs | frontend/scripts/capture-v106-r21-preview-states.mjs | 26C8067DCF10FF8F9B05F61F12B6753783B765A1DFBF22972BFB4D2A977C2D40 |
| scripts/verify_v106_r3_fix1_package.py | scripts/verify_v106_r3_fix1_package.py | BC6621D99C6E6A47F0B45CED23D0AE90F1D8AE43E4B6C8E48726DB4127DAEA7A |
| docs/generated_images/V10.6-R3-01-projects-empty.png | docs/generated_images/V10.6-R3-01-projects-empty.png | 2AA1DEBFEDC2C6792AFE48BD58C8C7CE25E6385659B4EDEF4B62A5348F1E72DF |
| docs/generated_images/V10.6-R3-02-r2-project-enter.png | docs/generated_images/V10.6-R3-02-r2-project-enter.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-03-workflow-source.png | docs/generated_images/V10.6-R3-03-workflow-source.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-04-plan-draft.png | docs/generated_images/V10.6-R3-04-plan-draft.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-05-unknown-partial.png | docs/generated_images/V10.6-R3-05-unknown-partial.png | 2BC18CD73E8CCFC1F425C42346F281A96E9D8737A51B48043E22A752C2C52443 |
| docs/generated_images/V10.6-R3-06-owner-edit.png | docs/generated_images/V10.6-R3-06-owner-edit.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-07-dependency-date.png | docs/generated_images/V10.6-R3-07-dependency-date.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-08-version-conflict.png | docs/generated_images/V10.6-R3-08-version-conflict.png | 2BC18CD73E8CCFC1F425C42346F281A96E9D8737A51B48043E22A752C2C52443 |
| docs/generated_images/V10.6-R3-09-plan-confirm.png | docs/generated_images/V10.6-R3-09-plan-confirm.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-10-schedule-generated.png | docs/generated_images/V10.6-R3-10-schedule-generated.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-11-task-progress.png | docs/generated_images/V10.6-R3-11-task-progress.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-12-overdue-reminder.png | docs/generated_images/V10.6-R3-12-overdue-reminder.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-13-csv-export.png | docs/generated_images/V10.6-R3-13-csv-export.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-14-no-permission.png | docs/generated_images/V10.6-R3-14-no-permission.png | 4658D0FB3F97DD81130CB624EE33BCC6CF82D2A8E351C46608B00301FEABEE1A |
| docs/generated_images/V10.6-R3-15-narrow-responsive.png | docs/generated_images/V10.6-R3-15-narrow-responsive.png | 4DA97055820839294E57F7DA31494B95AF89CB5EB31A093AF373B52B9D22921C |
| docs/generated_images/V10.6-R3-REAL-01-projects-page.png | docs/generated_images/V10.6-R3-REAL-01-projects-page.png | 7F797E60DF280612EF4C99913B842E385D6F30DEF7F88ED20C589F9E4A681F61 |
| docs/generated_images/V10.6-R3-REAL-02-tasks-progress-overdue.png | docs/generated_images/V10.6-R3-REAL-02-tasks-progress-overdue.png | 56CD6AC0AB5A581D7DB483F9E46251189A34A27CC86885707AAE24E427458920 |
| docs/generated_images/V10.6-R3-REAL-03-narrow-responsive.png | docs/generated_images/V10.6-R3-REAL-03-narrow-responsive.png | CBCAB1F76C44DF1AF0A70F73563FB7F8A14DD4DC68A2B6790894BE8A9E7E501F |
| docs/generated_images/V10.6-R3-REAL-04-no-permission.png | docs/generated_images/V10.6-R3-REAL-04-no-permission.png | F7145EEDBC3352B989F9044BF9AB170D1A7047EBA4B2186D8D8DC42E400791D0 |
| docs/generated_images/V10.6-R3-mock-state-blocked.png | docs/generated_images/V10.6-R3-mock-state-blocked.png | 8B619F249F4A772FBBF226CCD00A434EF52E9B2226DFEF0009890E7B187CACEF |
| docs/generated_images/V10.6-R3-mock-state-empty.png | docs/generated_images/V10.6-R3-mock-state-empty.png | 2AA1DEBFEDC2C6792AFE48BD58C8C7CE25E6385659B4EDEF4B62A5348F1E72DF |
| docs/generated_images/V10.6-R3-mock-state-error.png | docs/generated_images/V10.6-R3-mock-state-error.png | 5108C974AE22EBA10C92D9FB88F857C7EFDA667DF05DA189C512DFF419F46B76 |
| docs/generated_images/V10.6-R3-mock-state-loading.png | docs/generated_images/V10.6-R3-mock-state-loading.png | CCAE233F0DA8B807FF47867BDD476224E306128E5A13BEFAFA14F709DBD842AF |
| docs/generated_images/V10.6-R3-mock-state-no-permission.png | docs/generated_images/V10.6-R3-mock-state-no-permission.png | 4658D0FB3F97DD81130CB624EE33BCC6CF82D2A8E351C46608B00301FEABEE1A |
| docs/generated_images/V10.6-R3-mock-state-normal.png | docs/generated_images/V10.6-R3-mock-state-normal.png | 7CE99E333FEBA8282547B13794C041BC72EC66603F2F5D01492D2C577CCC497A |
| docs/generated_images/V10.6-R3-mock-state-partial.png | docs/generated_images/V10.6-R3-mock-state-partial.png | 2BC18CD73E8CCFC1F425C42346F281A96E9D8737A51B48043E22A752C2C52443 |

## 测试结果摘要

- 后端全量：325 passed。
- R3-FIX1 专项：25 passed。
- 前端测试：21 passed。
- TypeScript：通过。
- lint：通过，仅仓库原有 4 项 warning。
- production build：通过，54 个路由。
- 预览检查：PASS pages=36 meta=36 customerStates=7 projectStates=7。
- 交付包自检：PASS。

## 未完成项

- owner_defined 模板管理页未建设，JSON 提交已可用。
- R4 变更控制、问题库、Skill 沉淀未开发。

## 已知风险

- 真实页面截图来自本地隔离 fixture 数据，不代表生产环境。
- 提醒只做本地记录，不发送外部消息。

## 敏感信息检查结果

- 未包含 `.env`。
- 未包含 Token、API Key、客户隐私或数据库转储。
- 截图来自脱机 Mock 与隔离 fixture 环境。
