import test from "node:test";
import assert from "node:assert/strict";
import { APPLICATION_SURFACES } from "../../src/components/app-shell/surface-config";

test("operations surface protocol is implemented with frozen nav", () => {
  const protocol = APPLICATION_SURFACES.operations;
  assert.equal(protocol.protocolStatus, "implemented");
  assert.equal(protocol.navItems.length, 7);
  assert.deepEqual(
    protocol.navItems.map((item) => item.id),
    ["overview", "runtime", "connectors", "capabilities", "workflows", "reports", "system"],
  );
  assert.ok(protocol.navItems.every((item) => item.status === "open"));
});

test("governance surface protocol is implemented with frozen nav", () => {
  const protocol = APPLICATION_SURFACES.governance;
  assert.equal(protocol.protocolStatus, "implemented");
  assert.deepEqual(
    protocol.navItems.map((item) => item.id),
    ["permissions", "approvals", "audit", "risk", "collective"],
  );
});
