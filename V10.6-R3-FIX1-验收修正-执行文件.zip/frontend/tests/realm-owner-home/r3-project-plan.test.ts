import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  ownerDefinedTemplateValid,
  planCanUpdateTask,
  taskCanTransition,
} from "../../src/lib/realm-owner/r3-project-plan";

describe("R3 project plan UI interaction rules", () => {
  it("enforces strict task transitions", () => {
    assert.equal(taskCanTransition("planned", "in_progress"), true);
    assert.equal(taskCanTransition("planned", "completed"), false);
    assert.equal(taskCanTransition("in_progress", "blocked"), true);
    assert.equal(taskCanTransition("blocked", "in_progress"), true);
    assert.equal(taskCanTransition("completed", "in_progress"), false);
  });

  it("disables task updates after plan completion or task completion", () => {
    assert.equal(planCanUpdateTask(true, "plan_active", "planned"), true);
    assert.equal(planCanUpdateTask(true, "plan_completed", "planned"), false);
    assert.equal(planCanUpdateTask(true, "plan_active", "completed"), false);
    assert.equal(planCanUpdateTask(false, "plan_active", "planned"), false);
  });

  it("validates owner-defined template structure", () => {
    assert.equal(ownerDefinedTemplateValid({ phases: [{ phase: "阶段一", tasks: [] }] }), true);
    assert.equal(ownerDefinedTemplateValid({ phases: [] }), false);
    assert.equal(ownerDefinedTemplateValid(null), false);
  });
});
