# V10.6-R4-FIX2 最终收口交付 MANIFEST

- 任务编号：V10.6-R4-FIX2-FINAL-CLOSEOUT
- 前置版本：V10.6-R4-FIX1-ACCEPTANCE-CORRECTION
- 是否允许部署：否
- 是否允许提交或推送：否
- 交付包：V10.6-R4-FIX2-最终收口-执行文件.zip

## 文件清单（ZIP 路径 / 仓库源路径 / SHA-256）

`MANIFEST.md` 为本清单文件，不计算自身哈希；ZIP 内路径全部为 ASCII。

| ZIP路径（ASCII） | 仓库源路径 | SHA-256 |
| --- | --- | --- |
| docs/18-4_V10.6-R4-FIX2-final-closeout-report.md | docs/18-4_V10.6-R4-FIX2-final-closeout-report.md | 993C69DDBD7DEC77D6294AC03B962FFE438681711535E7FB857713663D63BB3E |
| docs/V10.6-R4-FIX2-code-change-list.md | docs/V10.6-R4-FIX2-code-change-list.md | 89CFEDB95C53050430121550B154EB9E309E1E82F7D21E220BCD462275E7DA2F |
| docs/18-3_V10.6-R4-FIX1-acceptance-correction-report.md | docs/18-3_V10.6-R4-FIX1-acceptance-correction-report.md | ACF29104B62722EE94FA14F7DD6DAE7685CCAAD8FB59D24C60B96C078855E649 |
| docs/V10.6-R4-FIX1-code-change-list.md | docs/V10.6-R4-FIX1-code-change-list.md | 392D7AFFA1C209F1D2183581135C7EF563DDB8946D07C6E0513B0C899573B9B2 |
| docs/18-2_V10.6-R4-execution-issue-closed-loop-report.md | docs/18-2_V10.6-R4-execution-issue-closed-loop-report.md | ECEC70E2343938958BA3316B48C6ED54C018FCED900531993B0D524587F02950 |
| docs/V10.6-R4-code-change-list.md | docs/V10.6-R4-code-change-list.md | FAC4EDE941DDB34728C41BE491E0DC0B3B6B01D66DCEF5D17A3B66EBA9EC950A |
| docs/v106-all-pages-design-preview.html | docs/v106-all-pages-design-preview.html | 4355B75D78481800CEF562F9B3613AF62C68F0FD6F10BB6BAF9FB3E0F20C78DB |
| docs/V10.6-UI-SYNC-PROTOCOL.md | docs/V10.6-UI-SYNC-PROTOCOL.md | F4CF4D1471902F131DEED0F6D9F6AC86E6BC0C5B7B810D8D04DF59373A7EFA84 |
| backend/app/services/issue_service.py | backend/app/services/issue_service.py | 84FEFA6FC108B3C46693F3CF064E1B644C7BF578F8D3DA76EF9877FC4EA149D6 |
| backend/app/api/v1/issues.py | backend/app/api/v1/issues.py | 09B4315AE1A3BC5641D942DC5612A7D9444A17C415D2B532F7589E9C36934586 |
| backend/app/models/issue.py | backend/app/models/issue.py | F666E6BD39350C2B6A81AF09683AEF6A06064FED7240C2237BD76B52B3410AEE |
| backend/tests/test_v10p6_r4_issue_closed_loop.py | backend/tests/test_v10p6_r4_issue_closed_loop.py | 9CD2F2FAECE0FF7C88EAC7C99FA700FF45CE2AEB5EA591F6BFF2B974AA28C9CE |
| frontend/src/lib/realm-owner/r4-issue.ts | frontend/src/lib/realm-owner/r4-issue.ts | 63F1F713D33CEE1B561CED87F6F7EA747746B5425098E02258677A3F7DD9E507 |
| frontend/src/components/realm-owner/issue-closed-loop-workbench.tsx | frontend/src/components/realm-owner/issue-closed-loop-workbench.tsx | 99D2F48002918B3BACC0F25F5892E1520879B5A7B7491BD89E443EAA98A68FAC |
| frontend/src/components/realm-owner/project-plan-workbench.tsx | frontend/src/components/realm-owner/project-plan-workbench.tsx | FDE0D0E21A91AFC6F54B5D3B91C7CA970DB172D89DBA4BB58943EC09FFBB2132 |
| frontend/src/components/realm-owner/realm-owner-section-page.tsx | frontend/src/components/realm-owner/realm-owner-section-page.tsx | F5C54A7438E7073D75721A14E1847DE106E5661BCC8544578A96072C3C23312A |
| frontend/src/components/app-shell/surface-config.ts | frontend/src/components/app-shell/surface-config.ts | 20CC819725B351FE56A6E4A755AA4010B7680433368BB66FD2BC92417E0C9E91 |
| frontend/src/app/realm/[realm_id]/execution/page.tsx | frontend/src/app/realm/[realm_id]/execution/page.tsx | 22DD834AE21050FDB395D6218B3F9A3315264BF30C89C1B963D584CDDFFC1382 |
| frontend/tests/realm-owner-home/r4-issue.test.ts | frontend/tests/realm-owner-home/r4-issue.test.ts | 463D6715FEE0811E2644CFAB3FD098247EC83AAF33679AC361143998A59DE79A |
| frontend/package.json | frontend/package.json | 0FF9E75EAC0930776C29106E047AD29394D6354ABF3834D338B1011B294A51AC |
| frontend/scripts/e2e-v106-r4-fix2.mjs | frontend/scripts/e2e-v106-r4-fix2.mjs | 60C5ACA6887F28055BC3F824388F6E224253AF311FE0E3FFBF89D0294ADA9E29 |
| frontend/scripts/capture-v106-r4-real-screenshots.mjs | frontend/scripts/capture-v106-r4-real-screenshots.mjs | 2F623885C4AE19470E0FCB06842765CABD2D9D1D4657CBCF79AE06369FED8D2B |
| frontend/scripts/check-v106-preview.mjs | frontend/scripts/check-v106-preview.mjs | 38CB7410AEE8B6463EA5AC259390A3B48A7D43E700AF479B0F66A8A9A2B229F3 |
| scripts/setup_v106_r4_fix2_fixture.py | scripts/setup_v106_r4_fix2_fixture.py | 248DC564599F895E491A2B5C56E6059FBFA20529438740CAAA9F8FA266DBE07B |
| scripts/verify_v106_r4_fix2_package.py | scripts/verify_v106_r4_fix2_package.py | 8422BCF53D306496324E1E87F1306562062BBB41EEA0A0D21B49311E80BE380E |
| docs/generated_images/V10.6-R4-REAL-01-issue-workbench.png | docs/generated_images/V10.6-R4-REAL-01-issue-workbench.png | B56DFA5F6655DB0400C878D4F34C554DC6C66B354E4FF643C57D53D0D7D1D957 |
| docs/generated_images/V10.6-R4-REAL-02-skill-draft.png | docs/generated_images/V10.6-R4-REAL-02-skill-draft.png | CC44D67E26C56625E22421003A35C22552583DAE2330487C4D53FF17A63512B1 |
| docs/generated_images/V10.6-R4-REAL-03-narrow-responsive.png | docs/generated_images/V10.6-R4-REAL-03-narrow-responsive.png | A204379FFE101AE1D9F5633066F9B3D167064B79414A62EDF90DA78CDF0CCAF2 |
| docs/generated_images/V10.6-R4-REAL-04-no-permission.png | docs/generated_images/V10.6-R4-REAL-04-no-permission.png | 03C0BFB94FEA765206A8801900CBB434C1C903C52029C12D61BC4326AC80405D |

## 测试结果摘要

- 后端全量：366 passed。
- R4-FIX2 专项：33 passed。
- 前端测试：28 passed。
- TypeScript：通过。
- lint：通过，仅仓库原有 4 项 warning。
- production build：通过，54 个路由。
- 预览检查：PASS pages=36 meta=36 customerStates=7 projectStates=7 issueStates=7。
- 真实 E2E：PASS，生成/编辑/版本冲突/确认/终态只读/verified 拒绝/幂等哈希 64 均通过。

## 未完成项

- R5、今日工作、能力市场、行业态势未开发。
- 外部 AI Provider 接入未启用，本地规则标记 rule_based。

## 已知风险

- Skill 草稿为内部业务资产，不等于系统级 SKILL.md。
- 提醒只做本地记录，不发送外部消息。
- 公网部署前仍需处理 Origin/CSRF、Referrer Policy、访问日志 Token 脱敏、资料保留与删除策略。

## 敏感信息检查结果

- 未包含 `.env`。
- 未包含 Token、API Key、客户隐私或数据库转储。
- 截图来自隔离 fixture 环境，不包含完整授权 Token。
- `idempotency_key` 仅返回 SHA-256 哈希，不返回原始客户端密钥。
